package com.senac.carrinhodecompra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarrinhodecompraApplicationTests {

	@Test
	void contextLoads() {
	}

}
