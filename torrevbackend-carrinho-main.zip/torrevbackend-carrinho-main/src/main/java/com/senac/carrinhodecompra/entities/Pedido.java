package com.senac.carrinhodecompra.entities;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;


@Entity
public class Pedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer pedido_id;
    private LocalDateTime pedido_data;
    private Integer usuario_id;
    @Column(precision = 10, scale = 2)
    private BigDecimal pedido_valor_total;
    private Integer pedido_status;
    @ManyToOne
    @JoinColumn(name = "cupom_id")
    private Cupom cupom;
    @Column(precision = 10, scale = 2)
    private BigDecimal pedido_desconto_aplicado;
    private String pedido_observacoes;

    @OneToMany(mappedBy = "pedido", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<PedidoItem> pedidosItens;
    public Pedido(){

    }

    public Pedido(Integer pedido_id, LocalDateTime pedido_data, Integer usuario_id, BigDecimal pedido_valor_total, Integer pedido_status, Cupom cupom, BigDecimal pedido_desconto_aplicado, String pedido_observacoes, List<PedidoItem> pedidosItens) {
        this.pedido_id = pedido_id;
        this.pedido_data = pedido_data;
        this.usuario_id = usuario_id;
        this.pedido_valor_total = pedido_valor_total;
        this.pedido_status = pedido_status;
        this.cupom = cupom;
        this.pedido_desconto_aplicado = pedido_desconto_aplicado;
        this.pedido_observacoes = pedido_observacoes;
        this.pedidosItens = pedidosItens;
    }

    public Integer getPedido_id() {
        return pedido_id;
    }

    public void setPedido_id(Integer pedido_id) {
        this.pedido_id = pedido_id;
    }

    public LocalDateTime getPedido_data() {
        return pedido_data;
    }

    public void setPedido_data(LocalDateTime pedido_data) {
        this.pedido_data = pedido_data;
    }

    public Integer getUsuario_id() {
        return usuario_id;
    }

    public void setUsuario_id(Integer usuario_id) {
        this.usuario_id = usuario_id;
    }

    public BigDecimal getPedido_valor_total() {
        return pedido_valor_total;
    }

    public void setPedido_valor_total(BigDecimal pedido_valor_total) {
        this.pedido_valor_total = pedido_valor_total;
    }

    public Integer getPedido_status() {
        return pedido_status;
    }

    public void setPedido_status(Integer pedido_status) {
        this.pedido_status = pedido_status;
    }

    public Cupom getCupom() {
        return cupom;
    }

    public void setCupom(Cupom cupom) {
        this.cupom = cupom;
    }

    public BigDecimal getPedido_desconto_aplicado() {
        return pedido_desconto_aplicado;
    }

    public void setPedido_desconto_aplicado(BigDecimal pedido_desconto_aplicado) {
        this.pedido_desconto_aplicado = pedido_desconto_aplicado;
    }

    public String getPedido_observacoes() {
        return pedido_observacoes;
    }

    public void setPedido_observacoes(String pedido_observacoes) {
        this.pedido_observacoes = pedido_observacoes;
    }

    public List<PedidoItem> getPedidosItens() {
        return pedidosItens;
    }

    public void setPedidosItens(List<PedidoItem> pedidosItens) {
        this.pedidosItens = pedidosItens;
    }
}
