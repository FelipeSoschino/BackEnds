package com.senac.carrinhodecompra.repositories;

import com.senac.carrinhodecompra.entities.Pedido;

import jakarta.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface PedidoRepository extends JpaRepository<Pedido, Integer> {
	
	//Query para deletar pedido
	@Modifying
	@Transactional
	@Query(value = "UPDATE Pedido SET pedido_status = -1 WHERE pedido_id = :id", nativeQuery = true)
	void deletarPedidoPorId(@Param("id") int id);
}
