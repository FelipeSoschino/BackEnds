package com.senac.carrinhodecompra.controllers;

import com.senac.carrinhodecompra.entities.Pedido;
import com.senac.carrinhodecompra.services.PedidoService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/pedido")
@Tag(name = "Pedido", description = "API para os pedidos")
public class PedidoController {

    private PedidoService pedidoService;

    public PedidoController(PedidoService pedidoService) {
        this.pedidoService = pedidoService;
    }
    
    // Endpoint - Adicionar
    @PostMapping("/adicionar")
    @Operation(summary = "Adicionar pedido", description = "Adicionar registro do pedido no banco")
    public ResponseEntity<Pedido> adicionarPedido(@RequestBody Pedido pedido){
        Pedido pedidoSalvo = pedidoService.adicionarPedido(pedido);
        return ResponseEntity.ok().body(pedidoSalvo);
    }
    
    // Endpoint - Excluir
    @DeleteMapping("excluir/{id}")
	@Operation(summary = "Excluir pedido por ID", description = "Delete lógico do registro do pedido no banco")
	public ResponseEntity<Map<String, String>> pedidosExcluidos(@PathVariable("id") Integer id){
		String mensagem = pedidoService.excluirPedido(id);
		
		Map<String, String> retorno = new HashMap<>();
	    retorno.put("mensagem", mensagem);

	    return ResponseEntity.ok(retorno);
		
	}
    
}
