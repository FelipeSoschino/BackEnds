package com.senac.carrinhodecompra.entities;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Entity
public class Cupom {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="cupom_id")
    private Integer id;
    @Column(length = 45)
    private String codigo;

    @Column(length = 300)
    private String descricao;

    private Integer tipo_desconto;

    @Column(precision = 10, scale = 2)
    private BigDecimal valor_desconto;
    private LocalDateTime validade;
    private Integer quantidade_uso;

    private Integer status;

    @OneToMany(mappedBy = "cupom")
    private List<Pedido> pedidos;

    public Cupom() {

    }

    public Cupom(List<Pedido> pedidos, String codigo, String descricao, Integer tipo_desconto, BigDecimal valor_desconto, LocalDateTime validade, Integer quantidade_uso, Integer status) {
        this.pedidos = pedidos;
        this.codigo = codigo;
        this.descricao = descricao;
        this.tipo_desconto = tipo_desconto;
        this.valor_desconto = valor_desconto;
        this.validade = validade;
        this.quantidade_uso = quantidade_uso;
        this.status = status;
    }

    public Integer getId() {
        return id;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Integer getTipo_desconto() {
        return tipo_desconto;
    }

    public void setTipo_desconto(Integer tipo_desconto) {
        this.tipo_desconto = tipo_desconto;
    }

    public BigDecimal getValor_desconto() {
        return valor_desconto;
    }

    public void setValor_desconto(BigDecimal valor_desconto) {
        this.valor_desconto = valor_desconto;
    }

    public LocalDateTime getValidade() {
        return validade;
    }

    public void setValidade(LocalDateTime validade) {
        this.validade = validade;
    }

    public Integer getQuantidade_uso() {
        return quantidade_uso;
    }

    public void setQuantidade_uso(Integer quntidade_uso) {
        this.quantidade_uso = quntidade_uso;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public List<Pedido> getPedidos() {
        return pedidos;
    }

    public void setPedidos(List<Pedido> pedidos) {
        this.pedidos = pedidos;
    }
}
