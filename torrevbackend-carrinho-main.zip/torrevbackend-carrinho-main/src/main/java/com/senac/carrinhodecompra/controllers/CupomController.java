package com.senac.carrinhodecompra.controllers;

import com.senac.carrinhodecompra.dto.CupomDTO;
import com.senac.carrinhodecompra.entities.Cupom;
import com.senac.carrinhodecompra.services.CupomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cupons")
public class CupomController {

    @Autowired
    private CupomService cupomService;

    @PostMapping
    public Cupom criarCupom(@RequestBody CupomDTO dto) {
        return cupomService.criarCupom(dto);
    }

    @PutMapping("/{id}")
    public Cupom atualizarCupom(@PathVariable Integer id, @RequestBody CupomDTO dto) {
        return cupomService.atualizarCupom(id, dto);
    }

    @GetMapping("/{id}")
    public Cupom buscarPorId(@PathVariable Integer id) {
        return cupomService.getCupomById(id);
    }

    @GetMapping
    public List<Cupom> listarTodos() {
        return cupomService.listarCupons();
    }

    @DeleteMapping("/{id}")
    public String deletar(@PathVariable Integer id) {
        return cupomService.deletarCupom(id);
    }
}
