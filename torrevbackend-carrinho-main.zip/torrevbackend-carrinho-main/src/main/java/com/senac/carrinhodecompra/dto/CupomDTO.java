package com.senac.carrinhodecompra.dto;

import com.senac.carrinhodecompra.entities.Pedido;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public class CupomDTO {
    private Integer id;
    private String codigo;
    private String descricao;
    private Integer tipo_desconto;
    private BigDecimal desconto;
    private LocalDateTime validade;
    private Integer quantidade_uso;
    private Integer status;
    private List<Pedido> pedidos;

    public List<Pedido> getPedidos() {
        return pedidos;
    }

    public void setPedidos(List<Pedido> pedidos) {
        this.pedidos = pedidos;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Integer getTipo_desconto() {
        return tipo_desconto;
    }

    public void setTipo_desconto(Integer tipo_desconto) {
        this.tipo_desconto = tipo_desconto;
    }

    public BigDecimal getValorDesconto() {
        return desconto;
    }

    public void setValorDesconto(BigDecimal desconto) {
        this.desconto = desconto;
    }

    public LocalDateTime getValidade() {
        return validade;
    }

    public void setValidade(LocalDateTime validade) {
        this.validade = validade;
    }

    public Integer getQuantidade_uso() {
        return quantidade_uso;
    }

    public void setQuantidade_uso(Integer quantidade_uso) {
        this.quantidade_uso = quantidade_uso;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public CupomDTO(Integer id, List<Pedido> pedidos, String codigo, String descricao, Integer tipo_desconto, BigDecimal valor_desconto, LocalDateTime validade, Integer quantidade_uso, Integer status) {
        this.id = id;
        this.pedidos = pedidos;
        this.codigo = codigo;
        this.descricao = descricao;
        this.tipo_desconto = tipo_desconto;
        this.desconto = valor_desconto;
        this.validade = validade;
        this.quantidade_uso = quantidade_uso;
        this.status = status;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}

