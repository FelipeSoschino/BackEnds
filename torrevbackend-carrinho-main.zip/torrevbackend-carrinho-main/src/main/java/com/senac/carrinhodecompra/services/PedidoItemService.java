package com.senac.carrinhodecompra.services;

import com.senac.carrinhodecompra.dto.PedidoItemDTO;
import com.senac.carrinhodecompra.entities.Pedido;
import com.senac.carrinhodecompra.entities.PedidoItem;
import com.senac.carrinhodecompra.repositories.PedidoItemRepository;
import com.senac.carrinhodecompra.repositories.PedidoRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PedidoItemService {

    @Autowired
    private PedidoItemRepository pedidoItemRepository;

    @Autowired
    private PedidoRepository pedidoRepository;

    // CREATE
    public PedidoItem adicionarItemAoPedido(PedidoItemDTO dto) {
        Pedido pedido = pedidoRepository.findById(dto.getPedidoId())
                .orElseThrow(() -> new EntityNotFoundException("Pedido com ID " + dto.getPedidoId() + " não encontrado"));

        PedidoItem item = new PedidoItem();
        item.setPedido(pedido);
        item.setEstoque_id(dto.getEstoqueId());
        item.setPedido_item_quantidade(dto.getPedidoItemQuantidade());
        item.setPedido_item_preco_unitario(dto.getPedidoItemPrecoUnitario());
        item.setPedido_item_sub_total(dto.getPedidoItemSubTotal());
        item.setPedido_item_status(dto.getPedidoItemStatus());

        return pedidoItemRepository.save(item);
    }

    // READ
    public List<PedidoItem> itensListados() {
        return pedidoItemRepository.findAll();
    }

    public PedidoItem buscarItemPorId(Integer id) {
        return pedidoItemRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Item com ID " + id + " não encontrado"));
    }

    // UPDATE
    public PedidoItem atualizarItem(Integer id, PedidoItemDTO dto) {
        PedidoItem item = pedidoItemRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Item com ID " + id + " não encontrado"));

        Pedido pedido = pedidoRepository.findById(dto.getPedidoId())
                .orElseThrow(() -> new EntityNotFoundException("Pedido com ID " + dto.getPedidoId() + " não encontrado"));

        item.setPedido(pedido);
        item.setEstoque_id(dto.getEstoqueId());
        item.setPedido_item_quantidade(dto.getPedidoItemQuantidade());
        item.setPedido_item_preco_unitario(dto.getPedidoItemPrecoUnitario());
        item.setPedido_item_sub_total(dto.getPedidoItemSubTotal());
        item.setPedido_item_status(dto.getPedidoItemStatus());

        return pedidoItemRepository.save(item);
    }

    // DELETE
    public String removerItem(Integer id) {
        if (!pedidoItemRepository.existsById(id)) {
            throw new EntityNotFoundException("Item com ID " + id + " não encontrado");
        }

        pedidoItemRepository.deleteById(id);
        return "Item " + id + ": excluído com sucesso!";
    }
}
