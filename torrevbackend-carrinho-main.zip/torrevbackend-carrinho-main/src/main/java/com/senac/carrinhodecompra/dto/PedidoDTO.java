package com.senac.carrinhodecompra.dto;

import java.time.LocalDateTime;
import java.util.List;

public class PedidoDTO {
    private Integer pedidoId;
    private LocalDateTime pedidoData;
    private Integer usuarioId;
    private Integer pedidoValorTotal;
    private Integer pedidoStatus;
    private CupomDTO cupom;
    private String pedidoDescontoAplicado;
    private String pedidoObservacoes;
    private List<PedidoItemDTO> pedidosItens;

    public PedidoDTO() {}

    public PedidoDTO(Integer pedidoId, LocalDateTime pedidoData, Integer usuarioId, Integer pedidoValorTotal,
                     Integer pedidoStatus, CupomDTO cupom, String pedidoDescontoAplicado,
                     String pedidoObservacoes, List<PedidoItemDTO> pedidosItens) {
        this.pedidoId = pedidoId;
        this.pedidoData = pedidoData;
        this.usuarioId = usuarioId;
        this.pedidoValorTotal = pedidoValorTotal;
        this.pedidoStatus = pedidoStatus;
        this.cupom = cupom;
        this.pedidoDescontoAplicado = pedidoDescontoAplicado;
        this.pedidoObservacoes = pedidoObservacoes;
        this.pedidosItens = pedidosItens;
    }

    public Integer getPedidoId() {
        return pedidoId;
    }

    public void setPedidoId(Integer pedidoId) {
        this.pedidoId = pedidoId;
    }

    public LocalDateTime getPedidoData() {
        return pedidoData;
    }

    public void setPedidoData(LocalDateTime pedidoData) {
        this.pedidoData = pedidoData;
    }

    public Integer getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(Integer usuarioId) {
        this.usuarioId = usuarioId;
    }

    public Integer getPedidoValorTotal() {
        return pedidoValorTotal;
    }

    public void setPedidoValorTotal(Integer pedidoValorTotal) {
        this.pedidoValorTotal = pedidoValorTotal;
    }

    public Integer getPedidoStatus() {
        return pedidoStatus;
    }

    public void setPedidoStatus(Integer pedidoStatus) {
        this.pedidoStatus = pedidoStatus;
    }

    public CupomDTO getCupom() {
        return cupom;
    }

    public void setCupom(CupomDTO cupom) {
        this.cupom = cupom;
    }

    public String getPedidoDescontoAplicado() {
        return pedidoDescontoAplicado;
    }

    public void setPedidoDescontoAplicado(String pedidoDescontoAplicado) {
        this.pedidoDescontoAplicado = pedidoDescontoAplicado;
    }

    public String getPedidoObservacoes() {
        return pedidoObservacoes;
    }

    public void setPedidoObservacoes(String pedidoObservacoes) {
        this.pedidoObservacoes = pedidoObservacoes;
    }

    public List<PedidoItemDTO> getPedidosItens() {
        return pedidosItens;
    }

    public void setPedidosItens(List<PedidoItemDTO> pedidosItens) {
        this.pedidosItens = pedidosItens;
    }
}

