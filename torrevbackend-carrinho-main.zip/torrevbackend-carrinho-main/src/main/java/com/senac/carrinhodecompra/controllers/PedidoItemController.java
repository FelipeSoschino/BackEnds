package com.senac.carrinhodecompra.controllers;

import com.senac.carrinhodecompra.dto.PedidoItemDTO;
import com.senac.carrinhodecompra.entities.PedidoItem;
import com.senac.carrinhodecompra.services.PedidoItemService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/pedido/item")
@Tag(name = "Itens do Pedido", description = "API para os itens presentes no carrinho")
public class PedidoItemController {

    private PedidoItemService pedidoItemService;

    public PedidoItemController(PedidoItemService pedidoItemService) {
        this.pedidoItemService = pedidoItemService;
    }

    @PostMapping("/adicionar")
    @Operation(summary = "Adicionar item", description = "Adicionar registro do item no banco")
    public ResponseEntity<PedidoItem> adicionarItemAoPedido(@RequestBody PedidoItemDTO dto) {
        PedidoItem pedidoItem = pedidoItemService.adicionarItemAoPedido(dto);
        return ResponseEntity.ok().body(pedidoItem);
    }

    @GetMapping("/list")
    public ResponseEntity<List<PedidoItem>> listarItens(){
        List<PedidoItem> itens = this.pedidoItemService.itensListados();
        return ResponseEntity.ok(itens);
    }
    
    // Endpoint - Excluir
    @DeleteMapping("remover/{id}")
	@Operation(summary = "Remover item do carrinho por ID", description = "Delete lógico do registro do item no banco")
	public ResponseEntity<Map<String, String>> pedidosExcluidos(@PathVariable("id") Integer id){
		String mensagem = pedidoItemService.removerItem(id);
		
		Map<String, String> retorno = new HashMap<>();
	    retorno.put("mensagem", mensagem);

	    return ResponseEntity.ok(retorno);
		
	}
}
