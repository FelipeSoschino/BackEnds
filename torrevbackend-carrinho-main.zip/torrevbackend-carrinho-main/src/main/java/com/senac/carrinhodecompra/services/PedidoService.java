package com.senac.carrinhodecompra.services;

import com.senac.carrinhodecompra.entities.Pedido;
import com.senac.carrinhodecompra.repositories.PedidoRepository;
import org.springframework.stereotype.Service;

@Service
public class PedidoService {

    private PedidoRepository pedidoRepository;

    public PedidoService(PedidoRepository pedidoRepository) {
        this.pedidoRepository = pedidoRepository;
    }
    
    // lógica para adicionar o pedido
    public Pedido adicionarPedido(Pedido pedido) {
        pedido.getPedidosItens().forEach(item -> item.setPedido(pedido));
        return pedidoRepository.save(pedido);
    }
    
    // lógica para excluir o pedido
    public String excluirPedido(Integer id) {
		if (!pedidoRepository.existsById(id)) {
			return "Pedido não encontrado!";
		}
		
		pedidoRepository.deletarPedidoPorId(id);
		return "Pedido " + id + " excluído com sucesso!";
	}
}

