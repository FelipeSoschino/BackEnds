package com.senac.carrinhodecompra.dto;

import java.math.BigDecimal;

public class PedidoItemDTO {
    private Integer pedidoItemId;
    private Integer estoqueId;
    private Integer pedidoItemQuantidade;
    private BigDecimal pedidoItemPrecoUnitario;
    private BigDecimal pedidoItemSubTotal;
    private Integer pedidoItemStatus;
    private Integer pedidoId;

    public PedidoItemDTO() {}

    public PedidoItemDTO(Integer pedidoItemId, Integer estoqueId, Integer pedidoItemQuantidade, BigDecimal pedidoItemPrecoUnitario, BigDecimal pedidoItemSubTotal, Integer pedidoItemStatus, Integer pedidoId) {
        this.pedidoItemId = pedidoItemId;
        this.estoqueId = estoqueId;
        this.pedidoItemQuantidade = pedidoItemQuantidade;
        this.pedidoItemPrecoUnitario = pedidoItemPrecoUnitario;
        this.pedidoItemSubTotal = pedidoItemSubTotal;
        this.pedidoItemStatus = pedidoItemStatus;
        this.pedidoId = pedidoId;
    }

    public Integer getPedidoItemId() {
        return pedidoItemId;
    }

    public void setPedidoItemId(Integer pedidoItemId) {
        this.pedidoItemId = pedidoItemId;
    }

    public Integer getEstoqueId() {
        return estoqueId;
    }

    public void setEstoqueId(Integer estoqueId) {
        this.estoqueId = estoqueId;
    }

    public Integer getPedidoItemQuantidade() {
        return pedidoItemQuantidade;
    }

    public void setPedidoItemQuantidade(Integer pedidoItemQuantidade) {
        this.pedidoItemQuantidade = pedidoItemQuantidade;
    }

    public BigDecimal getPedidoItemPrecoUnitario() {
        return pedidoItemPrecoUnitario;
    }

    public void setPedidoItemPrecoUnitario(BigDecimal pedidoItemPrecoUnitario) {
        this.pedidoItemPrecoUnitario = pedidoItemPrecoUnitario;
    }

    public BigDecimal getPedidoItemSubTotal() {
        return pedidoItemSubTotal;
    }

    public void setPedidoItemSubTotal(BigDecimal pedidoItemSubTotal) {
        this.pedidoItemSubTotal = pedidoItemSubTotal;
    }

    public Integer getPedidoItemStatus() {
        return pedidoItemStatus;
    }

    public void setPedidoItemStatus(Integer pedidoItemStatus) {
        this.pedidoItemStatus = pedidoItemStatus;
    }

    public Integer getPedidoId() {
        return pedidoId;
    }

    public void setPedidoId(Integer pedidoId) {
        this.pedidoId = pedidoId;
    }
}
