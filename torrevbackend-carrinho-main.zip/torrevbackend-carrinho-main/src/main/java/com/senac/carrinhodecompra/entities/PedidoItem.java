package com.senac.carrinhodecompra.entities;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

@Entity
@Table(name = "pedido_item")
public class PedidoItem {

    @ManyToOne
    @JoinColumn(name = "pedido_id")
    @JsonIgnore
    private Pedido pedido;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer pedido_item_id;
    private Integer estoque_id;
    private Integer pedido_item_quantidade;
    @Column(precision = 10, scale = 2)
    private BigDecimal pedido_item_preco_unitario;
    @Column(precision = 10, scale = 2)
    private BigDecimal pedido_item_sub_total;
    private Integer pedido_item_status;

    public PedidoItem() {

    }

    public PedidoItem(Pedido pedido, Integer pedido_item_id, Integer estoque_id, Integer pedido_item_quantidade, BigDecimal pedido_item_preco_unitario, BigDecimal pedido_item_sub_total, Integer pedido_item_status) {
        this.pedido = pedido;
        this.pedido_item_id = pedido_item_id;
        this.estoque_id = estoque_id;
        this.pedido_item_quantidade = pedido_item_quantidade;
        this.pedido_item_preco_unitario = pedido_item_preco_unitario;
        this.pedido_item_sub_total = pedido_item_sub_total;
        this.pedido_item_status = pedido_item_status;
    }

    public Pedido getPedido() {
        return pedido;
    }

    public void setPedido(Pedido pedido_id) {
        this.pedido = pedido_id;
    }

    public Integer getPedido_item_id() {
        return pedido_item_id;
    }

    public void setPedido_item_id(Integer pedido_item_id) {
        this.pedido_item_id = pedido_item_id;
    }

    public Integer getEstoque_id() {
        return estoque_id;
    }

    public void setEstoque_id(Integer estoque_id) {
        this.estoque_id = estoque_id;
    }

    public Integer getPedido_item_quantidade() {
        return pedido_item_quantidade;
    }

    public void setPedido_item_quantidade(Integer pedido_item_quantidade) {
        this.pedido_item_quantidade = pedido_item_quantidade;
    }

    public BigDecimal getPedido_item_preco_unitario() {
        return pedido_item_preco_unitario;
    }

    public void setPedido_item_preco_unitario(BigDecimal pedido_item_preco_unitario) {
        this.pedido_item_preco_unitario = pedido_item_preco_unitario;
    }

    public BigDecimal getPedido_item_sub_total() {
        return pedido_item_sub_total;
    }

    public void setPedido_item_sub_total(BigDecimal pedido_item_sub_total) {
        this.pedido_item_sub_total = pedido_item_sub_total;
    }

    public Integer getPedido_item_status() {
        return pedido_item_status;
    }

    public void setPedido_item_status(Integer pedido_item_status) {
        this.pedido_item_status = pedido_item_status;
    }
}
