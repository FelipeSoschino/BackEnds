package com.senac.carrinhodecompra.services;

import com.senac.carrinhodecompra.dto.CupomDTO;
import com.senac.carrinhodecompra.entities.Cupom;
import com.senac.carrinhodecompra.repositories.CupomRepository;
import com.senac.carrinhodecompra.repositories.PedidoRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CupomService {

    @Autowired
    private CupomRepository cupomRepository;

    @Autowired
    private PedidoRepository pedidoRepository;

    // CREATE
    public Cupom criarCupom(CupomDTO cupomDTO) {
        Cupom cupom = new Cupom();
        preencherDadosCupom(cupom, cupomDTO);
        return cupomRepository.save(cupom);
    }

    // READ por ID
    public Cupom getCupomById(Integer id) {
        return cupomRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Cupom com ID " + id + " não encontrado"));
    }

    // READ listar todos
    public List<Cupom> listarCupons() {
        return cupomRepository.findAll();
    }

    // UPDATE
    public Cupom atualizarCupom(Integer id, CupomDTO cupomDTO) {
        Cupom cupom = cupomRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Cupom com ID " + id + " não encontrado"));

        preencherDadosCupom(cupom, cupomDTO);
        return cupomRepository.save(cupom);
    }

    // DELETE
    public String deletarCupom(Integer id) {
        if (!cupomRepository.existsById(id)) {
            throw new EntityNotFoundException("Cupom com ID " + id + " não encontrado");
        }
        cupomRepository.deleteById(id);
        return "Cupom " + id + " excluído com sucesso!";
    }

    // Método auxiliar para preencher os dados
    private void preencherDadosCupom(Cupom cupom, CupomDTO dto) {
        cupom.setCodigo(dto.getCodigo());
        cupom.setDescricao(dto.getDescricao());
        cupom.setStatus(dto.getStatus());
        cupom.setValidade(dto.getValidade());
        cupom.setQuantidade_uso(dto.getQuantidade_uso());
        cupom.setTipo_desconto(dto.getTipo_desconto());
        cupom.setValor_desconto(dto.getValorDesconto());
        cupom.setPedidos(dto.getPedidos()); // ou null se não quiser setar aqui
    }
}
