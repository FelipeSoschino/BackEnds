import { Component } from '@angular/core';
import {EventEmitter, Input, Output } from '@angular/core';
import { Categoria } from '../../../core/models/categoria';
import { MatButtonModule } from '@angular/material/button';

export interface FiltrosSelecionados {
  categoriasSelecionadas: number[];
  textoBusca: string;
}

@Component({
  selector: 'app-filtro-categoria',
  standalone: true,
  imports: [MatButtonModule],
  templateUrl: './filtro-categoria.component.html',
  styleUrl: './filtro-categoria.component.css'
})
export class FiltroCategoriaComponent {

  categoriasTodas: Categoria [] = [
    { id: 0, nome: 'Produto', status: 0 },
    { id: 1, nome: 'Souvenir', status:0 },
    { id: 2, nome: 'Evento', status: 0 },
    { id: 3, nome: 'Doação', status: 0},
  ];
  @Input({ required: true }) categorias!: Categoria[];
  @Output() filtrosAlterados = new EventEmitter<FiltrosSelecionados>();

  categoriasSelecionadas: number[] = [];
  textoBusca: string = '';

  toggleCategoria(id: number): void {
    if (this.categoriasSelecionadas.includes(id)) {
      this.categoriasSelecionadas = this.categoriasSelecionadas.filter(c => c !== id);
    } else {
      this.categoriasSelecionadas.push(id);
    }

    this.emitirFiltros();
  }

  onBuscaChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.textoBusca = input.value;
    this.emitirFiltros();
  }

  emitirFiltros(): void {
    this.filtrosAlterados.emit({
      categoriasSelecionadas: this.categoriasSelecionadas,
      textoBusca: this.textoBusca.trim().toLowerCase()
    });
  }

}
