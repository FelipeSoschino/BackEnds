import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSidenavModule } from '@angular/material/sidenav';
import { CarrinhoComponent } from '../carrinho/carrinho.component';
import { Produto } from '../../core/models/produto';
import { PedidoService } from '../../shared/services/pedido.service';
import { ProdutoService } from '../../shared/services/produto.service';
import { EstoqueService } from '../../shared/services/estoque.service';
import { CarrinhoService } from '../../shared/services/carrinho.service';
import { Observable, of, switchMap, tap } from 'rxjs';
import { EstoqueResponse } from '../../core/models/estoqueResponse';
import { FiltroCategoriaComponent, FiltrosSelecionados } from './filtro-categoria/filtro-categoria.component';

@Component({
  selector: 'app-catalogo',
  standalone: true,
  imports: [CommonModule, MatSidenavModule, MatButtonModule, MatIconModule, CarrinhoComponent,FiltroCategoriaComponent],
  templateUrl: './catalogo.component.html',
  styleUrl: './catalogo.component.css'
})
export class CatalogoComponent implements OnInit{
  // Variaveis que vão lista produtos do backend e armazenar o ID do pedido
  produtos: Produto[] = [];
  pedidoIdDoUsuario: number | null = null;
  pedidoCriado: boolean = false;

  filtros: FiltrosSelecionados = {
    categoriasSelecionadas: [],
    textoBusca: ''
  };
categoriasDisponiveis: any;


  constructor(
    private pedidoService: PedidoService,
    private produtoService: ProdutoService,
    private estoqueService: EstoqueService,
    private carrinhoService: CarrinhoService
  ) {}

  ngOnInit() {
    this.getProdutosComPreco();
  }

  // Método para criar um pedido
  criarPedido(): Observable<any>{
    const novoPedido = {
      usuario_id: 1,
      pedido_data: null,
      pedido_valor_total: null,
      pedido_status: null,
      cupom: null,
      pedido_desconto_aplicado: 0,
      pedido_observacoes: null,
      pedidosItens: [],
    };
    return this.pedidoService.adicionarPedido(novoPedido).pipe(
      tap((response) => {
        this.pedidoIdDoUsuario = response?.pedido_id;
        this.pedidoCriado = true;
        console.log('criarPedido: Pedido ID recebido:', this.pedidoIdDoUsuario);
      })
    );
  }

  // Método para adicionar produto ao carrinho
  adicionarAoCarrinho(produto: Produto): void {
    this.carrinhoService.adicionarProduto(produto);
    const estoqueId = produto.estoqueId;
    const preco = produto.preco ?? 0;
    const quantidade = 1;

    if(!this.pedidoCriado) {
      this.criarPedido().pipe(
        switchMap((response: any) => {
        const pedidoId = response.pedido_id;
        this.pedidoIdDoUsuario = pedidoId;
        this.pedidoCriado = true;
        this.adicionarItemAoPedido(estoqueId, quantidade, pedidoId, preco);
        return of(null);
      })
    ).subscribe({
      next: (res) => console.log("Pedido criado com sucesso: ", res),
      error: (err) => console.error("Erro ao criar pedido: ", err)
    });
   } else if (this.pedidoIdDoUsuario !== null) {
    this.adicionarItemAoPedido(estoqueId, quantidade, this.pedidoIdDoUsuario, preco);
   } else {
    console.warn("Erro pedido ainda não foi criado corretamente.")
   }
  }

  // Método para criar pedido do Item
  criarPedidoDoItem(produto: Produto): void {
    const novoPedido = {
      pedidosItens: [{ produtoId: produto.id, quantidade: 1 }],
    };
    this.pedidoService.adicionarPedido(novoPedido).subscribe({
      next: (response: any) => {
        this.pedidoIdDoUsuario = response?.pedido_id;
        console.log('Pedido do usuário criado com ID:', this.pedidoIdDoUsuario);

        const estoqueId = produto.estoqueId;
        const quantidade = 1;
        const preco = produto.preco ?? 0;

        this.adicionarItemAoPedido(estoqueId, quantidade, this.pedidoIdDoUsuario!, preco);
      },
      error: (error) => {
        console.error('Erro ao criar pedido do item:', error);
        alert('Erro ao criar o pedido');
      },
    });
  }

  // Método para adicionar item ao pedido
  adicionarItemAoPedido(estoqueId: number, quantidade: number, pedidoIdDoUsuario: number, preco: number): void {
    this.pedidoService.adicionarItemAoPedido(
        estoqueId,
        quantidade,
        pedidoIdDoUsuario,
        preco
      ).subscribe({
        next: (response) => console.log('Item adicionado ao pedido:', response),
        error: (error) => console.error('Erro ao adicionar o item ao pedido:', error)
      });
  }

  // Buscar produtos com preços
  getProdutosComPreco(): void {
    this.produtoService.listarProdutos().subscribe({
      next: (produtosResponse: Produto[]) => {
        this.produtos = produtosResponse;
        const produtoIDs = this.produtos.map((p) => p.id);
        this.estoqueService.verificarEstoque(produtoIDs).subscribe({
          next: (estoqueList: EstoqueResponse[]) => {
            this.produtos.forEach((produto) => {
              const itemEstoque = estoqueList.find(
                (e) => e.produtoId === produto.id
              );
              produto.preco = itemEstoque?.valorVenda ?? 0;
            });
            console.log('Produtos com preços atualizados: ', this.produtos);
          },
          error: (err: any) => {
            console.error('Erro ao consultar estoque do produto: ', err);
          },
        });
      },
      error: (err: any) => {
        console.error('Erro ao buscar os dados dos produtos: ', err);
      },
    });
  }


  //Filtros

  onFiltrosAlterados(f: FiltrosSelecionados): void {
    this.filtros = f;
  }


  getProdutosFiltrados(): Produto[] {
    return this.produtos.filter(produto => {
      const correspondeCategoria =
        this.filtros.categoriasSelecionadas.length === 0 ||
        this.filtros.categoriasSelecionadas.includes(produto.categoriaId);

      const correspondeBusca =
        this.filtros.textoBusca === '' ||
        produto.nome.toLowerCase().includes(this.filtros.textoBusca);

      return correspondeCategoria && correspondeBusca;
    });
  }




}
