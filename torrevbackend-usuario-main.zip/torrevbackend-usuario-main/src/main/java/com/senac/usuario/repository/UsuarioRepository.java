package com.senac.usuario.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.senac.usuario.entities.Usuario;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Integer> {

    @Query("SELECT u FROM Usuario u WHERE u.status = :status")
    List<Usuario> findUsuariosByStatus(@Param("status") int status);

    @Query("SELECT u FROM Usuario u WHERE u.status = 1 AND u.id = :id")
    Optional<Usuario> findUsuariosByIdAtivo(@Param("id") int id);

    @Query("SELECT u FROM Usuario u WHERE u.status = 0")
    List<Usuario> findUsuariosInativos();

    @Modifying
    @Transactional
    @Query("UPDATE Usuario u SET u.status = -1 WHERE u.id = :id")
    void softDeleteById(@Param("id") int id);

}