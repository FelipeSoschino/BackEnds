package com.senac.usuario.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.senac.usuario.entities.Notificacao;
import com.senac.usuario.service.NotificacaoService;

@RestController
@RequestMapping(value = "/notificacao")
public class NotificacaoController {

    final private NotificacaoService notificacaoService;

    public NotificacaoController (NotificacaoService notificacaoService) {
        this.notificacaoService = notificacaoService;
    }

    @GetMapping("/listar")
    public ResponseEntity<List<Notificacao>> listarNotificacao() {
        List<Notificacao> notificacacoes = this.notificacaoService.listarNotificacaoAdmin();
        return ResponseEntity.ok(notificacacoes);
    }

    @GetMapping("/listar/{idUsuario}")
    public ResponseEntity<List<Notificacao>> listarNotificacaoUser(@PathVariable int idUsuario) {
        List<Notificacao> notificacacoes = this.notificacaoService.listarNotificacaoUsuario(idUsuario);
        return ResponseEntity.ok(notificacacoes);
    }

    @GetMapping("/notificacaomarcarlido/{idNotificacao}")
    public ResponseEntity notificacaoMarcarLido(@PathVariable int idNotificacao) {
        this.notificacaoService.marcarNotificacaoLido(idNotificacao);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/salvar")
    public ResponseEntity<Notificacao> salvarNotificacao(@RequestBody Notificacao notificacao) {
        Notificacao noti = this.notificacaoService.gravarNotificacao(notificacao);
        return ResponseEntity.ok(noti);
    }

    @GetMapping("/apagar/{idNotificacao}")
    public ResponseEntity apagarNotificacao(@PathVariable int idNotificacao) {
            this.notificacaoService.apagarNotificacao(idNotificacao);
        return ResponseEntity.noContent().build();
    }

}