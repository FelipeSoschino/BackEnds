package com.senac.usuario.dto.request;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class UsuarioDtoRequest {

    @NotBlank(message = "O nome do usuário é obrigatório")
    @Size(max = 300, message = "O nome deve ter até 300 caracteres.")
    private String nome;

    @NotBlank(message = "O E-mail do usuário é obrigatório")
    @Size(max = 45, message = "O E-mail deve ter até 45 caracteres.")
    private String email;

    @NotBlank(message = "A identificação do usuário é obrigatória")
    @Size(max = 45, message = "A identificação deve ter até 45 caracteres.")
    private String identificacao;

    @NotNull(message = "O tipo do usuário é obrigatório")
    @Max(value = 99999999999L, message = "O tipo do usuário deve ter até 11 dígitos.")
    private Integer tipo;

    @Size(max = 300, message = "O endereço deve ter até 300 caracteres.")
    private String endereco;

    @Size(max = 45, message = "O código postal deve ter até 45 caracteres.")
    private String codigoPostal;

    @Size(max = 45, message = "A nacionalidade deve ter até 45 caracteres.")
    private String nacionalidade;

    @JsonIgnore
    private LocalDateTime dataCriacao = LocalDateTime.now();

    @JsonIgnore
    private byte[] fotoPerfil; //E para armazenar a imagem

    @NotNull(message = "O status do usuário é obrigatório")
    private Integer status;

    @NotNull(message = "O Id do usuário responsável pela criação desse usuário é obrigatório")
    private Integer usuarioResponsavel;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getIdentificacao() {
        return identificacao;
    }

    public void setIdentificacao(String identificacao) {
        this.identificacao = identificacao;
    }

    public Integer getTipo() {
        return tipo;
    }

    public void setTipo(Integer tipo) {
        this.tipo = tipo;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getCodigoPostal() {
        return codigoPostal;
    }

    public void setCodigoPostal(String codigoPostal) {
        this.codigoPostal = codigoPostal;
    }

    public String getNacionalidade() {
        return nacionalidade;
    }

    public void setNacionalidade(String nacionalidade) {
        this.nacionalidade = nacionalidade;
    }

    public LocalDateTime getDataCriacao() {
        return dataCriacao;
    }

    public void setDataCriacao(LocalDateTime dataCriacao) {
        this.dataCriacao = dataCriacao;
    }

    public byte[] getFotoPerfil() {
        return fotoPerfil;
    }

    public void setFotoPerfil(byte[] fotoPerfil) {
        this.fotoPerfil = fotoPerfil;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getUsuarioResponsavel() {
        return usuarioResponsavel;
    }

    public void setUsuarioResponsavel(Integer usuarioResponsavel) {
        this.usuarioResponsavel = usuarioResponsavel;
    }



}