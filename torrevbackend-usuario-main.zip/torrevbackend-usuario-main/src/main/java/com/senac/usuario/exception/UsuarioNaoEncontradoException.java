package com.senac.usuario.exception;

public class UsuarioNaoEncontradoException extends RuntimeException {
    /**
     * Como o RuntimeException implementa o serializable inclui esse identificador abaixo para evitar erro ao serializar/deserializar
     */
    private static final long serialVersionUID = 1L;

    public UsuarioNaoEncontradoException(String message) {
        super(message);
    }
}