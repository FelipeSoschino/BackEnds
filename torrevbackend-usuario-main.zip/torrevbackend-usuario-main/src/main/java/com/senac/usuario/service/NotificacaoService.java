package com.senac.usuario.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.senac.usuario.entities.Notificacao;
import com.senac.usuario.repository.NotificacaoRepository;


@Service
public class NotificacaoService {
    private final NotificacaoRepository notificacaoRepository;

    public NotificacaoService(NotificacaoRepository notificacaoRepository) {
        this.notificacaoRepository = notificacaoRepository;
    }

    public List<Notificacao> listarNotificacaoAdmin() {
        return this.notificacaoRepository.listarNotificacaoAdmin();
    }

    public List<Notificacao> listarNotificacaoUsuario(int id) {
        return this.notificacaoRepository.listarNotificacaoUsuario(id);
    }
    public void marcarNotificacaoLido(int id) {
        this.notificacaoRepository.marcarNotificacaoLido(id);
    }

    public Notificacao gravarNotificacao(Notificacao notificacao) {
        return this.notificacaoRepository.save(notificacao);
    }

    public void apagarNotificacao(int id) {
        this.notificacaoRepository.softDeleteById(id);
    }
}