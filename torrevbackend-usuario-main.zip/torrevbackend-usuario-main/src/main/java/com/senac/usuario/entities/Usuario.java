package com.senac.usuario.entities;


import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;

@Entity
@Table(name= "usuario")
public class Usuario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "usuario_id", nullable = false)
    private int id;

    @Column(name = "usuario_nome", length = 300, nullable = false)
    private String name;

    @Column(name = "usuario_email", length = 45, nullable = false)
    private String email;

    @Column(name = "usuario_identificacao", length = 45, nullable = false)
    private String identificacao;

    @Column(name = "usuario_tipo", nullable = false)
    private int tipo;

    @Column(name = "usuario_endereco", length = 300)
    private String endereco;

    @Column(name = "usuario_codigo_postal", length = 45)
    private String codigoPostal;

    @Column(name = "usuario_nacionalidade", length = 45)
    private String nacionalidade;

    @Column(name = "usuario_data_criacao", nullable = false)
    private LocalDateTime dataCriacao;

    @Lob
    @Column(name = "usuario_foto_perfil", nullable = false)
    private byte[] fotoPerfil;

    @Column(name = "usuario_status", nullable = false)
    private int status;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getIdentificacao() {
        return identificacao;
    }

    public void setIdentificacao(String identificacao) {
        this.identificacao = identificacao;
    }

    public int getTipo() {
        return tipo;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getCodigo_postal() {
        return codigoPostal;
    }

    public void setCodigo_postal(String codigo_postal) {
        this.codigoPostal = codigo_postal;
    }

    public String getNacionalidade() {
        return nacionalidade;
    }

    public void setNacionalidade(String nacionalidade) {
        this.nacionalidade = nacionalidade;
    }

    public LocalDateTime getDataCriacao() {
        return dataCriacao;
    }

    public void setDataCriacao(LocalDateTime dataCriacao) {
        this.dataCriacao = dataCriacao;
    }

    public byte[] getFoto_perfil() {
        return fotoPerfil;
    }

    public void setFoto_perfil(byte[] foto_perfil) {
        this.fotoPerfil = foto_perfil;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

}