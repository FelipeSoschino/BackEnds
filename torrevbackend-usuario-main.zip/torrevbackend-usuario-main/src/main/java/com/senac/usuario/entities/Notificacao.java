package com.senac.usuario.entities;


import java.time.LocalDateTime;

import jakarta.persistence.*;

@Entity
@Table(name= "notificacao")
public class Notificacao {

    @Id
    @Column(name="notificacao_id")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int Id;
    @Column(name="notificacao_assunto")
    private String assunto;
    @Column(name="notificacao_corpo")
    private String corpo;
    @Column(name="notificacao_tipo")
    private int tipo;
    @Column(name="notificacao_data_hora")
    private LocalDateTime dataHora;
    @Column(name="notificacao_status")
    private int status;
    @Column(name="usuario_id")
    private int usuarioId;

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getAssunto() {
        return assunto;
    }

    public void setAssunto(String assunto) {
        this.assunto = assunto;
    }

    public String getCorpo() {
        return corpo;
    }

    public void setCorpo(String corpo) {
        this.corpo = corpo;
    }

    public int getTipo() {
        return tipo;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }

    public void setDataHora(LocalDateTime dataHora) {
        this.dataHora = dataHora;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }
}