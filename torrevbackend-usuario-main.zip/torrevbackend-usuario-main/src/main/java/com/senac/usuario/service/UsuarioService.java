package com.senac.usuario.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.senac.usuario.entities.Usuario;
import com.senac.usuario.exception.UsuarioNaoEncontradoException;
import com.senac.usuario.repository.UsuarioRepository;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    public List<Usuario> listarUsuariosAtivos(){
        return this.usuarioRepository.findUsuariosByStatus(1);
    }

    public List<Usuario> listarUsuariosInativos(){
        return this.usuarioRepository.findUsuariosInativos();
    }

    public Usuario cadastrarUsuario (Usuario usuario) {
        usuario.setStatus(1);
        return this.usuarioRepository.save(usuario);
    }

    public Usuario updateUsuario(Usuario usuario) {
        usuario.setStatus(1);
        this.buscarUsuarioPorId(usuario.getId());
        return usuarioRepository.save(usuario);
    }

    public void softDeleteUsuarioById(int id) {
        this.buscarUsuarioPorId(id);
        usuarioRepository.softDeleteById(id);
    }

    public Usuario buscarUsuarioPorId(int id) { //buscar usuario por id que vai servir para outros métodos acima
        return usuarioRepository.findUsuariosByIdAtivo(id).orElseThrow(() -> new UsuarioNaoEncontradoException("Usuário com ID " + id + " não encontrado para deleção"));
    }

}