package com.senac.usuario.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.senac.usuario.entities.Notificacao;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface NotificacaoRepository extends JpaRepository<Notificacao, Integer> {

    @Query("SELECT n FROM Notificacao n")
    List<Notificacao>listarNotificacaoAdmin();


    @Query("SELECT n FROM Notificacao n where n.usuarioId = :id and n.status >= 0")
    List<Notificacao>listarNotificacaoUsuario(@Param("id") int id);


    @Modifying
    @Transactional
    @Query("UPDATE Notificacao n SET n.status = 2 WHERE n.id = :id")
    void marcarNotificacaoLido(@Param("id") int id);

    @Modifying
    @Transactional
    @Query("UPDATE Notificacao n SET n.status = -1 WHERE n.id = :id")
    void softDeleteById(@Param("id") int id);

}