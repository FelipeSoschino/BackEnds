package senacbanco;

import java.sql.SQLException;
import java.util.Scanner;

import dao.ContatoDao;

public class TestaContatoDaoScanner {
	public static void main(String[] args) {
		Contato con1 = new Contato();
			Scanner scn = new Scanner(System.in); 
			String nome ="";
			String email ="";
			String endereco= "";
			
			System.out.println("Entre com os dados para inserir um novo contato na agenda."
					+ "\nCaso deseje sair digite: \"sair\"");
			
			boolean x = true;
			while (true){
				System.out.print("Entre com o nome: ");
				nome = scn.nextLine();
				if (nome.toLowerCase().equals("sair")) {
					break;
				}
				System.out.print("\nEntre com o email: ");
				email = scn.nextLine();
				if (email.toLowerCase().equals("sair")) {
					break;
				}
				System.out.print("\nEntre com o endereco: ");
				endereco = scn.nextLine();
				if (endereco.toLowerCase().equals("sair")) {
					break;
				}

				
					con1.setNome(nome);
					con1.setEndereco(endereco);
					con1.setEmail(email);
					
				ContatoDao dao;
				try {
					dao = new ContatoDao();
					dao.addContact(con1);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					}
				break;
				}
				scn.close();
				System.out.println("Você saiu do programa");
			} 
		}
		
		

