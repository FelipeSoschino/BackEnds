package senacbanco;

import java.sql.SQLException;
import java.util.List;

import dao.ContatoDao;

public class TestaContatoDaoLista {

	public static void main(String[] args) {
	
		// TODO Auto-generated method stub
		try {
			ContatoDao cdao;	
				cdao = new ContatoDao();
				List<Contato> contatos = cdao.getLista();
				
				for (Contato contato : contatos) {
					System.out.println("Nome: "+contato.getNome());
					System.out.println("E-mail: "+contato.getEmail());
					System.out.println("Endereço: "+contato.getEndereco());
					System.out.println("-------------------------------------");
				}
			
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

}
