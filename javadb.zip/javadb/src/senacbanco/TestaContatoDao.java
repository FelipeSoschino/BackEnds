package senacbanco;

import java.sql.SQLException;

import dao.ContatoDao;

public class TestaContatoDao {
	public static void main(String[] args) {
		Contato con1 = new Contato();
		con1.setNome("Joao");
		con1.setEmail("joao@joao.com");
		con1.setEndereco("Av Brasil, Rj, n# 1000");
		
		Contato con2 = new Contato();
		con2.setNome("Maroa");
		con2.setEmail("maria@maria.com");
		con2.setEndereco("Av Brasil, Rj, n# 1000");
		
		ContatoDao dao;
		try {
			dao = new ContatoDao();
			dao.addContact(con1);
			dao.addContact(con2);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
