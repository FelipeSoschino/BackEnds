package senacbanco;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class TestaInsere {
	public static void main(String[] args) {
		try {
			String insert = "insert into contatos(nome, email, endereco) values (?, ?, ?)";
			Connection con = ConnectionFactory.getConnection();
			PreparedStatement stmt = con.prepareStatement(insert); // prepara variavel que ira inserir informações
			stmt.setString(1,"Darley");
			stmt.setString(2,"darley@dvaaz.com");
			stmt.setString(3,"casinha de palha");
			stmt.execute(); // pega os dados e lança no banco de dados
			stmt.close(); // fecha o stream
			System.out.println("Gravação feita com sucesso");
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

}
