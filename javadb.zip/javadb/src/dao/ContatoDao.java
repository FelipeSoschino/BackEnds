package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import senacbanco.ConnectionFactory;
import senacbanco.Contato;

public class ContatoDao {
	private Connection con;
	
	public ContatoDao() throws SQLException {
		this.con = ConnectionFactory.getConnection();
	}
	
	public void addContact(Contato contato) throws SQLException {
		String insert = "insert into contatos(nome, email, endereco) values (?, ?, ?)";
		Connection con = ConnectionFactory.getConnection();
		PreparedStatement stmt = con.prepareStatement(insert); // prepara variavel que ira inserir informações
		stmt.setString(1, contato.getNome());
		stmt.setString(2, contato.getEmail());
		stmt.setString(3, contato.getEndereco());
		stmt.execute(); // pega os dados e lança no banco de dados
		stmt.close(); // fecha o stream
//		System.out.println("Gravação feita com sucesso");
		con.close();
		
	}
	
	
	public List<Contato> getLista() throws SQLException{
		String query = "select * from contatos";
		PreparedStatement stmt = con.prepareStatement(query);
		ResultSet rset = stmt.executeQuery();
		
		List<Contato> contatos = new ArrayList<Contato>();
		
		while(rset.next()){
			Contato contato = new Contato();
			contato.setNome(rset.getString("nome"));
			contato.setEmail(rset.getString("email"));
			contato.setEndereco(rset.getString("endereco"));
			
			contatos.add(contato);
		}
		
		rset.close();
		stmt.close();
		return contatos;		
	}
	
	public List<Contato> pesquisarInicial(char x) throws SQLException{
		String query = "select * from contatos where nome like '"+x+"%'";
		PreparedStatement stmt = con.prepareStatement(query);
		ResultSet rset = stmt.executeQuery();
		
		List<Contato> contatos = new ArrayList<Contato>();
		
		while(rset.next()){
			Contato contato = new Contato();
			contato.setNome(rset.getString("nome"));
			contato.setEmail(rset.getString("email"));
			contato.setEndereco(rset.getString("endereco"));
			
			contatos.add(contato);
		}
		
		rset.close();
		stmt.close();
		
		
		return contatos;	
	}
	
	public Contato contatoPorId(int id) throws SQLException {
		String query = "select * from contatos WHERE id = "+id;
		PreparedStatement stmt = con.prepareStatement(query);
		ResultSet rset = stmt.executeQuery();
		
		Contato contato = new Contato();
		contato.setNome(rset.getString("nome"));
		contato.setEmail(rset.getString("email"));
		contato.setEndereco(rset.getString("endereco"));

		
		return contato;
		
	}
	
	
	
	
	
	
}
