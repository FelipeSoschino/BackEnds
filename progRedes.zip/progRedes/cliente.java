package progRedes;

import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class cliente {
	public static void main(String[] args) throws UnknownHostException, IOException {
		Socket client = new Socket("127.0.0.1",10000);
		System.out.println("Cliente conectado ao servidor!");
		
		
		Scanner scan = new Scanner(System.in);		
		PrintStream out = new PrintStream(client.getOutputStream());
		
		while (scan.hasNextLine()) {
			out.print(scan.nextLine());
			
		}
		
		scan.close();
		out.close();
		client.close();
	}

}
