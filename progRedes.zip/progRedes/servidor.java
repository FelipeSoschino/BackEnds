package progRedes;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class servidor {
	
	public static void main(String[] args) throws IOException {
		ServerSocket sck = new ServerSocket(10000);
		System.out.println("Porta 10000 aberta, aguardando conexão...");
		
		Socket client = sck.accept();
		System.out.println("Conexão do cliente " + client.getInetAddress().getHostAddress());
		
		
		Scanner scan = new Scanner(client.getInputStream());
		
		while (scan.hasNextLine()) {
			
			System.out.println(scan.nextLine());
			
			
		}
		
		scan.close();
		sck.close();
		client.close();
	}

}
