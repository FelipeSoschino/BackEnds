package mensageiro;
// melhorar o nome da classe
public class ConectionErrors {
// Possiveis erros de conexão, utilizar o try catch
	// É melhor centralizar ou não?
	//  error de conexao ao servidor
	public void handleServerError(String errorMessage, Throwable exception) {
        System.err.println("Server error: " + errorMessage);
        exception.printStackTrace();
    }
	// erro de conexao com o client
    public void handleConnectionError(String errorMessage, Throwable exception) {
        System.err.println("Client Error: " + errorMessage);
        exception.printStackTrace();
    }

    //erro não previsto
    public void handleGenericError(String errorMessage, Throwable exception) {
        System.err.println("Generic I/O error: " + errorMessage);
        exception.printStackTrace();
    }

}