package mensageiro;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;


public class Servidor {
	private ServerSocket serverSocket;
	// private Socket client;
	private ConectionErrors errorhandler;
	private InetAddress ip; 

	// construtor
	public Servidor(ServerSocket port) throws IOException {
		    this.serverSocket = (port); // cria o server socket na porta especificada
		    this.ip = InetAddress.getLocalHost();
			System.out.println(" IP: " + ip.getHostAddress());
//			this.startServer();
	}
	
	public void startServer() {
		try {
			while (!serverSocket.isClosed()) {
				Socket socket = serverSocket.accept();
				System.out.println("Novo client connectado");
				// ClientHub será uma classe que lida com vários clients através de threads
				ClientHub clientHub = new ClientHub(socket); // aqui a magica acontece
				Thread tClientHub = new Thread(clientHub); // na verdade uma thread que irá gerenciar a conexão de quantos clientes forem conectados
				tClientHub.start();
			}
		} catch (IOException e) {
			closeServerSocket();
			errorhandler.handleServerError("Não foi possível iniciar o servidor", e);
		}
	}
	
	public void closeServerSocket() {
		try {
			if(serverSocket != null) {
				serverSocket.close();
			}
		} catch (IOException e) {
			errorhandler.handleServerError("Não foi possivel fechar o server socket " , e);
		}
	}

 //
  public static void main(String[] args) throws IOException {
//	  ServerSocket severSocket = new ServerSocket(Integer.parseInt(args[0])); // port com args
		System.out.print("Digite o número da porta de conexão: ");
		Scanner scn = new Scanner(System.in);
		int port = 0;
		try {
			String portS="";
			while (port < 1024 || port > 65535) {
				System.out.println("A porta tem de ser maior que 1024 e menor que 65535");
				System.out.println("Digite o número da porta de conexão: ");
				portS = scn.nextLine();
				port = Integer.parseInt(portS.trim());
				}

			} catch (Exception e) {
				scn.close();
				System.out.println("Não foi possivel acessar uma porta");
		        e.printStackTrace();
			}
	  ServerSocket severSocket = new ServerSocket(port);
   	  System.out.println("Servidor iniciado na porta: " + severSocket.getLocalPort());
	  Servidor server = new Servidor(severSocket); 
	  server.startServer();
	  
  }
}