package mensageiro;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {

	private Socket socket;
	private BufferedReader bffReader;
	private BufferedWriter bffWriter;
	private String username;
	
	public Client (Socket socket, String username) {
		try {
			this.socket = socket;
			OutputStreamWriter outWriter = new OutputStreamWriter(socket.getOutputStream()); // empacota o bytestream em um character string
			this.bffWriter = new BufferedWriter(outWriter);
			InputStreamReader inReader = new InputStreamReader(socket.getInputStream()); // empacota o bytestream em um inputsreamreader que ira traduzir para char
			this.bffReader = new BufferedReader(inReader);
			this.username = username;

			
		} catch (IOException e) {
			
			closeClient (socket, bffWriter, bffReader);
		}
	}
	
	public void sendMessage() {
		try {
			bffWriter.write(username);
			bffWriter.newLine();
			bffWriter.flush();
			
			Scanner scn = new Scanner(System.in);
			while (socket.isConnected()) {
				String messageToSend = scn.nextLine();
				bffWriter.write(username + " > " + messageToSend);
				bffWriter.newLine();
				bffWriter.flush(); // grava garantindo a integridade dos dados
				
			}
			scn.close();
		} catch (IOException e) {
			
			closeClient(socket, bffWriter, bffReader);
		}
	}
	
	public void listenForMessage() {
		//thread incoming, com muita ajuda
		new Thread(new Runnable() {
			@Override
			public void run() {
				String msgFromGroupChat; // rmber to create private msg
				while (socket.isConnected()) {
					try {
						msgFromGroupChat = bffReader.readLine();
						System.out.println(msgFromGroupChat);
					} catch (IOException e) {
						closeClient(socket, bffWriter, bffReader);
					}
				}
			}
		}).start(); // que coisa bacana, abri uma Trrhead direto no método sem invocar o implements (não saberia fazer sozinho) 
	}
	
	public void closeClient(Socket socket, BufferedWriter bffWriter, BufferedReader bffReader) {
		try {
			if (bffReader != null) {
				bffReader.close();
			}
			if (bffWriter != null) {
				bffWriter.close();
			}
			if (socket != null) {
				socket.close();
			}
			
		} catch (IOException e) { // informa os erros em stack
			e.printStackTrace();
		}
	}
		// invocará o Swing para criar a interface gráfica
	public static void main (String[] args) throws UnknownHostException, IOException {
		
		Scanner scn = new Scanner(System.in);
		int port = 0;
		String ip = "";
		try {
			System.out.println("Digite o ip do servidor: ");
			ip = scn.nextLine();
			ip.trim();
			String portS="";
			while (port < 1024 || port > 65535) {
				System.out.println("A porta tem de ser maior que 1024 e menor que 65535");
				System.out.println("Digite o número da porta de conexão: ");
				portS = scn.nextLine();
				port = Integer.parseInt(portS.trim());
				}


			} catch (Exception e) {
				System.out.println("Não foi possivel realizar a conexão");
		        e.printStackTrace();
			}
		System.out.println("\nDigite como deseja ser chamado na sala de chat: ");
		String username = scn.nextLine();
//		Socket socket = new Socket(args[0], Integer.parseInt(args[1])); // mudar para o IP do servidor , porta exemplo 1881
		Socket socket = new Socket(ip, port);
		Client client = new Client(socket, username);
		client.listenForMessage(); // escuta as mensagens do servidor
		client.sendMessage(); // envia as mensagens para o servidor
		scn.close();
	}
	
}
