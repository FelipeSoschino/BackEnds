package mensageiro;

//import java.util.regex.*; // importando regex para validar o id do client, https://docs.oracle.com/javase/8/docs/api/java/util/regex/Pattern.html
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
 // O client Hub é responsável por gerenciar a conexão de cada cliente, receber mensagens e distribuí-las para todos os outros clientes conectados.
 // https://docs.oracle.com/javaee/7/api/javax/websocket/MessageHandler.html
public class ClientHub implements Runnable{
//	public static int clientIdCounter = 0; // contador de ids dos clientes conectados
	public static List<ClientHub> ClientHubs = new ArrayList<>(); //  lista de clientes conectados e seus ids
	// A lista é estática para que todos os objetos ClientHub compartilhem a mesma lista de clientes conectados.
	private Socket socket;
	private BufferedReader bffReader;
	private BufferedWriter bffWriter;
	private String clientUserName;
//	private int clientId; // id do cliente, atribuído no construtor
	// private String clientIp; // endereço IP do cliente seria utilizado para localizar o cliente, mas não é necessário para o funcionamento do chat

	private ConectionErrors errorHandler;
	

	// constructor
	public ClientHub (Socket socket) { // interceptor de conexões, recebe o socket do cliente
		try {
			// System.out.println("Novo cliente conectado: " + socket.getInetAddress().getHostAddress()); // descomente para ver o endereço IP do cliente conectado
			this.socket = socket;
			// this.clientIp = socket.getInetAddress().getHostAddress(); // armazena o endereço IP do cliente
			OutputStreamWriter outWriter = new OutputStreamWriter(socket.getOutputStream()); // empacota o bytestream em um character string
			this.bffWriter = new BufferedWriter(outWriter);
			InputStreamReader inReader = new InputStreamReader(socket.getInputStream()); // empacota o bytestream em um inputsreamreader que ira traduzir para char
			this.bffReader = new BufferedReader(inReader);
			this.clientUserName = bffReader.readLine(); // recebe nome de usuario conforme entrada na classe Client
//			this.clientId = clientIdCounter; // atribui um id ao cliente
//			clientIdCounter++; // incrementa o contador de ids dos clientes conectados
			ClientHubs.add(this);
			broadcastMessage("Servidor: "+ clientUserName+ " entrou na sala!");
			
		} catch (IOException e) { 
			errorHandler.handleConnectionError("Não foi possível conectar o cliente ao socket"+socket, e);
			closeClientConection(socket, bffReader, bffWriter);
		}
	}
	
	@Override
	public void run() { // Thread que lida com a conexão do cliente, recebendo e enviando mensagens
		// ouvindo as mensagens com threads para nao "parar" o programa
		String messageSentFromClient;
		
		while (socket.isConnected()) {
			try {
				messageSentFromClient = bffReader.readLine();
				broadcastMessage(messageSentFromClient);
			} catch (IOException e ) {
				errorHandler.handleGenericError("Thread error ", e);
				closeClientConection(socket, bffReader, bffWriter);
				break;
			}
		}
		
	}

	// public void privateMessage(String sentMessage, int clientId) {
	// 	// f0rmata mensagem privada facilitando a identificacao do cliente, separando o client da mensagem atraves de regex
	
	// 	// retorna para o cliente em caso de falha
	// }

	public void broadcastMessage (String sentMessage) {
		for (ClientHub cltHub : ClientHubs) {
			try {
		// 		// Inicio do teste de mensagem privada
		// 		Pattern pattern = Pattern.compile("?(\\d+)@(\\w+)>"); // regex para validar o id do cliente
        // 		Matcher matcher = pattern.matcher(sentMessage);
		// 		boolean isPrivateMessage = matcher.find(); // verifica se a mensagem é privada
		// 		ClientHub clientIdPrivado = null; // inicializa variavel para guardar id do client

		// 		if (isPrivateMessage) { // se a mensagem for privada
		// 			// obteriamos o id ou ip do cliente, mas ele tb teria de ser servidor.
		// 			// outra opcao seria fazer de todo cliente também um servidor, mas aumentaria a vunerabilidade do usuario e do sistema
		// 			// o client hub / handler poderia ainda escolher o o cliente que recebe a mensagem... mas como?

		//   } else {
		// 	  System.out.println("Usuário não encontrado: ");

		//   }
				// 	// fim do teste... favor mudar para hasmap ou map
					
				// }	

				if (!cltHub.clientUserName.equals(clientUserName)) {
					cltHub.bffWriter.write(sentMessage);
					cltHub.bffWriter.newLine(); // enter
					cltHub.bffWriter.flush(); // garante que o que foi escrito sera gravado e enviado e fecha esse ""stream"
					
				}

			} catch (IOException e) {
				errorHandler.handleConnectionError("Mensagem não enviada ", e);
				closeClientConection(socket, bffReader, bffWriter);
			}
		}
	}
	
	public void removerClientHub() { // remove o client da lista de clientes conectados
		ClientHubs.remove(this);
		broadcastMessage("Server: " + clientUserName+ " saiu da sala.");
	}
	
	public void closeClientConection(Socket socket, BufferedReader bffReader, BufferedWriter bffWriter) {
		removerClientHub();
		try {
			if (bffReader != null) {
				bffReader.close();
			}
			if (bffWriter != null) {
				bffWriter.close();
			}
			if (socket != null) {
				socket.close();
			}
		} catch (IOException e) { // informa a segunda sequencia, caso haja erro
			errorHandler.handleGenericError("Erro ao fechar a conexão do cliente", e);
		}
	}
}
