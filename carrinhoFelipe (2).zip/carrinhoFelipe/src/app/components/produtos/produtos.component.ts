import { Component, OnInit } from '@angular/core';
import { ProdutosService } from '../../services/produtos.service';
import { MatCardModule } from '@angular/material/card';
import { MatGridListModule } from '@angular/material/grid-list';

@Component({
  selector: 'app-produtos',
  standalone: true,
  imports: [MatCardModule, MatGridListModule],
  templateUrl: './produtos.component.html',
  styleUrl: './produtos.component.css'
})
export class ProdutosComponent implements OnInit {
  listaProdutos: any;
  cols: number = 3;

  constructor(private produtosService: ProdutosService) {}

  ngOnInit(): void {
    this.getProdutos();
  }

  getProdutos(): void {
    this.produtosService.getProdutos().subscribe({
      next: (res) => {
        this.listaProdutos = res;
        console.log(this.listaProdutos);
      },
      error: (err) => {
        console.error(err);
      }
    });
  }
}
