import { Component, OnInit } from '@angular/core';
import { CarrinhoService } from '../../services/carrinho.service';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatGridListModule } from '@angular/material/grid-list';

@Component({
  selector: 'app-carrinho',
  imports: [MatCardModule, MatButtonModule,MatPaginatorModule,MatGridListModule],
  templateUrl: './carrinho.component.html',
  styleUrl: './carrinho.component.css'
})
export class CarrinhoComponent implements OnInit {
  listaItems:any;
cols: number = 2;
// colspan: number = 1;
precoReal: number = 1.0;
contPreco: number = 35154.96;

  constructor(private carrinhoServ: CarrinhoService){}
  ngOnInit(): void {
    this.getCarrinho();

  }

  getCarrinho(): void{
    this.carrinhoServ.getCarrinho().subscribe({
      next: (response)=>{
        this.listaItems = response;
        console.log(this.listaItems);
      },
        error:(error)=> console.log(error),
    })
    this.precoFinal();
  }
  removeItem(item: any) {
    this.listaItems = this.listaItems.filter((i: any) => i !== item); //essa função cria outra lista sem o item selecionado.
    this.precoFinal();}                                                //Descobri essa função tentando fazer o componente filtros na outra tarefa
  adiciona(item: any) {
    this.precoReal = item.price/item.quantity;
    item.quantity++;
    item.price = parseFloat((this.precoReal*item.quantity).toFixed(2));
    this.precoFinal();

  }


  diminui(item: any) {
    this.precoReal = item.price/item.quantity;
    if (item.quantity > 1) {
      item.quantity--;
      item.price = parseFloat((this.precoReal*item.quantity).toFixed(2));
      this.precoFinal();
    }

  }

  // atualizaPreco(item: any): void{
  //   this.precoReal = item.price/item.quantity;
  //   item.price = parseFloat(this.precoReal.toFixed(2));
  // }


  precoFinal():void{
    let cont = 0.0;
    for (let x = 0;x<this.listaItems.length;x++){
      cont += this.listaItems[x].price;

    }
    this.contPreco = parseFloat(cont.toFixed(2));
  }

}




