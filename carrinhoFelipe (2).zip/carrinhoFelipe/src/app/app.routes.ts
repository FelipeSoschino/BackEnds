import { Routes } from '@angular/router';
import { CarrinhoComponent } from './components/carrinho/carrinho.component';

export const routes: Routes = [
  // {path: 'carrinho', component: CarrinhoComponent}
];
