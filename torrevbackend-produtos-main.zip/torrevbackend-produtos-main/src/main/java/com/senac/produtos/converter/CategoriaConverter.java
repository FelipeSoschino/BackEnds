package com.senac.produtos.converter;

import com.senac.produtos.dto.CategoriaDTO;
import com.senac.produtos.model.Categoria;
import com.senac.produtos.model.enums.CategoriaStatus;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.function.Function;

@Component
public class CategoriaConverter implements Function<CategoriaDTO, Categoria> {

    @Override
    public Categoria apply(CategoriaDTO categoriaDTO) {
        Objects.requireNonNull(categoriaDTO, "CategoriaDTO não pode ser nulo");

        Categoria categoria = new Categoria();
        categoria.setNome(categoriaDTO.getNome());
        categoria.setStatus(CategoriaStatus.fromCodigo(categoriaDTO.getStatus()));

        return categoria;
    }
}