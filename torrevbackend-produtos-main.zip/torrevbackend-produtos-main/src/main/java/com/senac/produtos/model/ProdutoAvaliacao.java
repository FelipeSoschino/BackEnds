package com.senac.produtos.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.senac.produtos.converter.ProdutoAvaliacaoStatusConverter;
import com.senac.produtos.model.enums.ProdutoAvaliacaoStatus;
import jakarta.persistence.*;
import jakarta.validation.constraints.Null;

import java.time.LocalDate;

@Entity
@Table(name = "produto_avaliacao")
public class ProdutoAvaliacao {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "produto_avaliacao_id")
    private Long id;
    @Column(name = "produto_avaliacao_descricao")
    private String descricao;
    @Column(name = "produto_avaliacao_data")
    private LocalDate data;
    @Column(name = "produto_avaliacao_nota")
    private Integer nota;
    @Column(name = "produto_avaliacao_status")
    @Convert(converter = ProdutoAvaliacaoStatusConverter.class)
    private ProdutoAvaliacaoStatus status;

    @ManyToOne
    @JoinColumn(name = "produto_id", nullable = true)
    @Null
    @JsonIgnore
    private Produto produto;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public Integer getNota() {
        return nota;
    }

    public void setNota(Integer nota) {
        this.nota = nota;
    }

    public ProdutoAvaliacaoStatus getStatus() {
        return status;
    }

    public void setStatus(ProdutoAvaliacaoStatus status) {
        this.status = status;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }
}
