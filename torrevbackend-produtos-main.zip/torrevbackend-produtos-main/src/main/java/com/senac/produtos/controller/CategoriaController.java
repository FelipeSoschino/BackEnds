package com.senac.produtos.controller;

import com.senac.produtos.dto.CategoriaDTO;
import com.senac.produtos.service.CategoriaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("api/v1/categoria")
@Tag(name = "Categoria", description = "API para gerenciamento de categorias")
public class CategoriaController {

    private final CategoriaService categoriaService;

    @Autowired
    public CategoriaController(CategoriaService categoriaService) {
        this.categoriaService = categoriaService;
    }

    @GetMapping("/ativos")
    @Operation(summary = "Listar categorias de status ativo", description = "Lista todos as categorias com status ativo")
    public ResponseEntity<List<CategoriaDTO>> listarCategoriasAtivas() {
        return ResponseEntity.ok(categoriaService.listarCategoriasAtivas());
    }

    @PostMapping
    @Operation(summary = "Criar nova categoria", description = "Cria um novo registro de categoria")
    public ResponseEntity<CategoriaDTO> criarCategoria(@Valid @RequestBody CategoriaDTO categoriaDTO) {
        CategoriaDTO novaCategoria = categoriaService.criarCategoria(categoriaDTO);
        URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
                .buildAndExpand(novaCategoria.getId()).toUri();
        return ResponseEntity.created(uri).body(novaCategoria);
    }

    @DeleteMapping("/{idCategoria}")
    @Operation(summary = "Excluir categoria", description = "Exclui uma categoria existente pelo ID")
    public ResponseEntity<Void> excluirCategoria(@PathVariable("idCategoria") Long id) {
        categoriaService.excluirCategoria(id);
        return ResponseEntity.noContent().build();
    }
}
