package com.senac.produtos.dto;

import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;

public class ProdutoAvaliacaoDTO {
    private Long id;
    private String descricao;
    private LocalDate data;
    private Integer nota;
    @NotNull(message = "Status é obrigatório.")
    private Integer status;
    @NotNull(message = "ID do Produto é obrigatório.")
    private Long produtoId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public Integer getNota() {
        return nota;
    }

    public void setNota(Integer nota) {
        this.nota = nota;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Long getProdutoId() {
        return produtoId;
    }

    public void setProdutoId(Long produtoId) {
        this.produtoId = produtoId;
    }
}
