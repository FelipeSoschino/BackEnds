package com.senac.produtos.dto.request;

import jakarta.validation.constraints.NotNull;

import java.util.List;

public class ProdutoEstoqueRequestDTO {
    @NotNull
    private List<Long> ids;

    // Getters e Setters
    public List<Long> getIds() {
        return ids;
    }

    public void setIds(List<Long> ids) {
        this.ids = ids;
    }
}
