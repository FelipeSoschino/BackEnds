package com.senac.produtos.model.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum FabricanteStatus {
    INATIVO(0),
    ATIVO(1);


    private final int codigo;

    FabricanteStatus(int codigo) {
        this.codigo = codigo;
    }

    @JsonValue
    public int getCodigo() {
        return codigo;
    }

    @JsonCreator
    public static FabricanteStatus fromCodigo(int codigo) {
        for (FabricanteStatus status : FabricanteStatus.values()) {
            if (status.codigo == codigo) {
                return status;
            }
        }
        throw new IllegalArgumentException("Código inválido: " + codigo);
    }
}