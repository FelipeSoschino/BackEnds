package com.senac.produtos.controller;

import com.senac.produtos.dto.ProdutoAvaliacaoDTO;
import com.senac.produtos.service.ProdutoAvaliacaoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("api/v1/produtoavaliacao")
@Tag(name = "ProdutoAvaliacao", description = "API para gerenciamento de produto_avaliacao")
public class ProdutoAvaliacaoController {
    private final ProdutoAvaliacaoService produtoAvaliacaoService;

    @Autowired
    public ProdutoAvaliacaoController(ProdutoAvaliacaoService produtoAvaliacaoService) {
        this.produtoAvaliacaoService = produtoAvaliacaoService;
    }

    @GetMapping("/ativos")
    @Operation(summary = "Listar estoques de eventos de status ativo", description = "Lista todos os estoques eventos com status ativo")
    public ResponseEntity<List<ProdutoAvaliacaoDTO>> listarProdutosAvaliacaoAtivos() {
        return ResponseEntity.ok(produtoAvaliacaoService.listarProdutosAvaliacoesAtivos());
    }

    @PostMapping
    @Operation(summary = "Criar nova avaliação de produto", description = "Cria um novo registro de avaliação de produto")
    public ResponseEntity<ProdutoAvaliacaoDTO> criarProdutoAvaliacao(@Valid @RequestBody ProdutoAvaliacaoDTO produtoAvaliacaoDTO) {
        ProdutoAvaliacaoDTO novoProdutoAvaliacao = produtoAvaliacaoService.criarProdutoAvaliacao(produtoAvaliacaoDTO);
        URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
                .buildAndExpand(novoProdutoAvaliacao.getId()).toUri();
        return ResponseEntity.created(uri).body(novoProdutoAvaliacao);
    }

    @DeleteMapping("/{idProdutoAvalicao}")
    @Operation(summary = "Excluir uma avaliação do produto", description = "Exclui uma avaliação do produto existente pelo ID")
    public ResponseEntity<Void> excluirProdutoAvaliacao(@PathVariable("idProdutoAvalicao") Long id) {
        produtoAvaliacaoService.excluirProdutoAvaliacao(id);
        return ResponseEntity.noContent().build();
    }

}
