package com.senac.produtos.converter;

import com.senac.produtos.model.enums.CategoriaStatus;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

@Converter(autoApply = true)
public class CategoriaStatusConverter implements AttributeConverter<CategoriaStatus, Integer> {

    @Override
    public Integer convertToDatabaseColumn(CategoriaStatus status) {
        return status == null ? null : status.getCodigo();
    }

    @Override
    public CategoriaStatus convertToEntityAttribute(Integer status) {
        if (status == null) {
            return null;
        }
        return CategoriaStatus.fromCodigo(status);
    }
}
