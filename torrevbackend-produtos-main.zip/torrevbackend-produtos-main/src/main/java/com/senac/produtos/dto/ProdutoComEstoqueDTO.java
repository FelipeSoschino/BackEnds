package com.senac.produtos.dto;


import com.senac.produtos.model.Produto;

public class ProdutoComEstoqueDTO {

    private Long id;
    private String nome;
    private String descricao;
    private Integer quantidadeEstoque;

    // Construtor
    public ProdutoComEstoqueDTO(Produto produto, Integer quantidadeEstoque) {
        this.id = produto.getId();
        this.nome = produto.getNome();
        this.descricao = produto.getDescricao();
        this.quantidadeEstoque = quantidadeEstoque;
    }

    // Getters (Obrigatórios para o JSON)
    public Long getId() { return id; }
    public String getNome() { return nome; }
    public String getDescricao() { return descricao; }
    public Integer getQuantidadeEstoque() { return quantidadeEstoque; }
}
