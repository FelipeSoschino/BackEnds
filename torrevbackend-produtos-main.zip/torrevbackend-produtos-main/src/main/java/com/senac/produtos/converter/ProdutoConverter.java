package com.senac.produtos.converter;

import com.senac.produtos.dto.ProdutoDTO;
import com.senac.produtos.model.Produto;
import com.senac.produtos.model.enums.ProdutoStatus;
import com.senac.produtos.model.enums.ProdutoTipo;
import com.senac.produtos.repository.CategoriaRepository;
import com.senac.produtos.repository.FabricanteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.function.Function;

@Component
public class ProdutoConverter implements Function<ProdutoDTO, Produto> {

    private final FabricanteRepository fabricanteRepository;
    private final CategoriaRepository categoriaRepository;

    @Autowired
    public ProdutoConverter(FabricanteRepository fabricanteRepository, CategoriaRepository categoriaRepository) {
        this.fabricanteRepository = fabricanteRepository;
        this.categoriaRepository = categoriaRepository;
    }

    @Override
    public Produto apply(ProdutoDTO produtoDTO) {
        Objects.requireNonNull(produtoDTO, "ProdutoDTO não pode ser nulo");

        Produto produto = new Produto();
        produto.setNome(produtoDTO.getNome());
        produto.setDescricao(produtoDTO.getDescricao());
        produto.setStatus(ProdutoStatus.fromCodigo(produtoDTO.getStatus()));
        produto.setTipo(ProdutoTipo.fromCodigo(produtoDTO.getTipo()));

        produto.setFabricante(
                fabricanteRepository.findById(produtoDTO.getFabricanteId())
                        .orElseThrow(() -> new IllegalArgumentException("Fabricante não encontrado com ID: " + produtoDTO.getFabricanteId()))
        );

        produto.setCategoria(
                categoriaRepository.findById(produtoDTO.getCategoriaId())
                        .orElseThrow(() -> new IllegalArgumentException("Categoria não encontrado com ID: " + produtoDTO.getCategoriaId()))
        );

        return produto;
    }
}