package com.senac.produtos.converter;

import com.senac.produtos.dto.CategoriaDTO;
import com.senac.produtos.model.Categoria;
import org.springframework.stereotype.Component;

import java.util.function.Function;

@Component
public class CategoriaDTOConverter implements Function<Categoria, CategoriaDTO> {

    @Override
    public CategoriaDTO apply(Categoria categoria) {

        if (categoria == null) {
            return null;
        }

        CategoriaDTO dto = new CategoriaDTO();
        dto.setId(categoria.getId());
        dto.setNome(categoria.getNome());
        dto.setStatus(categoria.getStatus().getCodigo());
        return dto;
    }
}