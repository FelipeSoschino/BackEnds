package com.senac.produtos.service;


import com.senac.produtos.converter.FabricanteConverter;
import com.senac.produtos.converter.FabricanteDTOConverter;
import com.senac.produtos.dto.FabricanteDTO;
import com.senac.produtos.model.Fabricante;
import com.senac.produtos.model.enums.FabricanteStatus;
import com.senac.produtos.repository.FabricanteRepository;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FabricanteService {

    private final FabricanteRepository fabricanteRepository;
    private final FabricanteConverter fabricanteConverter;
    private final FabricanteDTOConverter fabricanteDTOConverter;

    public FabricanteService(FabricanteRepository fabricanteRepository, FabricanteConverter fabricanteConverter, FabricanteDTOConverter fabricanteDTOConverter) {
        this.fabricanteRepository = fabricanteRepository;
        this.fabricanteConverter = fabricanteConverter;
        this.fabricanteDTOConverter = fabricanteDTOConverter;
    }

    @Transactional
    public FabricanteDTO criarFabricante(FabricanteDTO fabricanteDTO) {
        Fabricante fabricante = fabricanteConverter.apply(fabricanteDTO);
        Fabricante fabricanteSalvo = fabricanteRepository.save(fabricante);
        return fabricanteDTOConverter.apply(fabricanteSalvo);
    }

    public List<FabricanteDTO> listarFabricantesAtivos() {
        List<Fabricante> fabricantes = fabricanteRepository.findByStatus(FabricanteStatus.ATIVO);
        return fabricantes.stream()
                .map(fabricanteDTOConverter)
                .toList();
    }

    @Transactional
    public void excluirFabricante(Long id) {
        if (!fabricanteRepository.existsById(id)) {
            throw new EntityNotFoundException("Fabricante com id: "+ id +" não encontrado");
        }
        fabricanteRepository.deletarFabricantePorId(id);
    }
}
