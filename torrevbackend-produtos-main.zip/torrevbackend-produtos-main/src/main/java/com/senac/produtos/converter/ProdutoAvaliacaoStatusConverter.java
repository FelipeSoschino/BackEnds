package com.senac.produtos.converter;

import com.senac.produtos.model.enums.ProdutoAvaliacaoStatus;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

@Converter(autoApply = true)
public class ProdutoAvaliacaoStatusConverter implements AttributeConverter<ProdutoAvaliacaoStatus, Integer> {

    @Override
    public Integer convertToDatabaseColumn(ProdutoAvaliacaoStatus status) {
        return status == null ? null : status.getCodigo() ;
    }

    @Override
    public ProdutoAvaliacaoStatus convertToEntityAttribute(Integer status) {
        if (status == null) {
            return null;
        }
        return ProdutoAvaliacaoStatus.fromCodigo(status);
    }
}
