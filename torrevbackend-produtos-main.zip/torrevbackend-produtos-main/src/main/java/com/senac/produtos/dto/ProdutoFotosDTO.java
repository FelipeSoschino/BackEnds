package com.senac.produtos.dto;

import jakarta.validation.constraints.NotNull;

public class ProdutoFotosDTO {
    private Long id;
    @NotNull
    private Byte foto;
    private Integer inicial;
    private String nomearquivo;
    private String extensaoarquivo;
    private Integer status;
    @NotNull(message = "ID do Produto é obrigatório.")
    private Long produtoId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Byte getFoto() {
        return foto;
    }

    public void setFoto(Byte foto) {
        this.foto = foto;
    }

    public Integer getInicial() {
        return inicial;
    }

    public void setInicial(Integer inicial) {
        this.inicial = inicial;
    }

    public String getNomearquivo() {
        return nomearquivo;
    }

    public void setNomearquivo(String nomearquivo) {
        this.nomearquivo = nomearquivo;
    }

    public String getExtensaoarquivo() {
        return extensaoarquivo;
    }

    public void setExtensaoarquivo(String extensaoarquivo) {
        this.extensaoarquivo = extensaoarquivo;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Long getProdutoId() {
        return produtoId;
    }

    public void setProdutoId(Long produtoId) {
        this.produtoId = produtoId;
    }
}
