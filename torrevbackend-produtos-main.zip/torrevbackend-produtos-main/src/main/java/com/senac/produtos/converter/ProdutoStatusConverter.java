package com.senac.produtos.converter;

import com.senac.produtos.model.enums.ProdutoStatus;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

@Converter(autoApply = true)
public class ProdutoStatusConverter implements AttributeConverter<ProdutoStatus, Integer> {

    @Override
    public Integer convertToDatabaseColumn(ProdutoStatus status) {
        return status == null ? null : status.getCodigo();
    }

    @Override
    public ProdutoStatus convertToEntityAttribute(Integer status) {
        if (status == null) {
            return null;
        }
        return ProdutoStatus.fromCodigo(status);
    }
}
