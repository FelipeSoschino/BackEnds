package com.senac.produtos.controller;

import com.senac.produtos.dto.ProdutoFotosDTO;
import com.senac.produtos.service.ProdutoFotosService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("api/v1/produtofotos")
@Tag(name = "ProdutoFotos", description = "API para gerenciamento de fotos dos produtos")
public class ProdutoFotosController {
    private final ProdutoFotosService produtoFotosService;

    @Autowired
    public ProdutoFotosController(ProdutoFotosService produtoFotosService) {
        this.produtoFotosService = produtoFotosService;
    }

    @GetMapping("/ativos")
    @Operation(summary = "Listar fotos de produtos de status ativo", description = "Lista todos as fotos de produtos com status ativo")
    public ResponseEntity<List<ProdutoFotosDTO>> listarProdutoFotosAtivos() {
        return ResponseEntity.ok(produtoFotosService.listarProdutoFotosAtivos());
    }

    @PostMapping
    @Operation(summary = "Criar nova foto do produto", description = "Cria um novo registro de foto de produto")
    public ResponseEntity<ProdutoFotosDTO> criarProdutoFoto(@Valid @RequestBody ProdutoFotosDTO produtoFotosDTO) {
        ProdutoFotosDTO novoProdutoFoto = produtoFotosService.criarProdutoFoto(produtoFotosDTO);
        URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
                .buildAndExpand(novoProdutoFoto.getId()).toUri();
        return ResponseEntity.created(uri).body(novoProdutoFoto);
    }

    @DeleteMapping("/{idProdutoFoto}")
    @Operation(summary = "Excluir a foto de um produto", description = "Exclui uma foto do produto existente pelo ID")
    public ResponseEntity<Void> excluirProdutoFotos(@PathVariable("idProdutoFoto") Long id) {
        produtoFotosService.excluirProdutoFotos(id);
        return ResponseEntity.noContent().build();
    }
}
