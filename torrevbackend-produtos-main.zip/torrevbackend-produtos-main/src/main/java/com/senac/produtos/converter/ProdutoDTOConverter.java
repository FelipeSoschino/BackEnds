package com.senac.produtos.converter;

import com.senac.produtos.dto.ProdutoDTO;
import com.senac.produtos.model.Produto;
import org.springframework.stereotype.Component;

import java.util.function.Function;

@Component
public class ProdutoDTOConverter implements Function<Produto, ProdutoDTO> {

    @Override
    public ProdutoDTO apply(Produto produto) {

        if (produto == null) {
            return null;
        }

        ProdutoDTO dto = new ProdutoDTO();
        dto.setId(produto.getId());
        dto.setNome(produto.getNome());
        dto.setDescricao(produto.getDescricao());
        dto.setStatus(produto.getStatus().getCodigo());
        dto.setTipo(produto.getTipo().getCodigo());
        dto.setFabricanteId(produto.getFabricante().getId());
        dto.setCategoriaId(produto.getCategoria().getId());
        return dto;
    }
}