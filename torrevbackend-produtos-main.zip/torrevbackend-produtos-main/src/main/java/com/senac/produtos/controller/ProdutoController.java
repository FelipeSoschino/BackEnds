package com.senac.produtos.controller;

import com.senac.produtos.dto.ProdutoComEstoqueDTO;
import com.senac.produtos.dto.ProdutoDTO;
import com.senac.produtos.dto.request.ProdutoEstoqueRequestDTO;
import com.senac.produtos.dto.response.EstoqueResponseDTO;
import com.senac.produtos.model.Produto;
import com.senac.produtos.service.ProdutoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("api/v1/produto")
@Tag(name = "Produto", description = "API para gerenciamento de produtos")
public class ProdutoController {

    private final ProdutoService produtoService;

    @Autowired
    public ProdutoController(ProdutoService produtoService) {
        this.produtoService = produtoService;
    }

    @GetMapping("/ativos")
    @Operation(summary = "Listar produtos de status ativo", description = "Lista todos os produtos com status ativo")
    public ResponseEntity<List<ProdutoDTO>> listarProdutosAtivos() {
        return ResponseEntity.ok(produtoService.listarProdutosAtivos());
    }

    @GetMapping("/ativo/{idProduto}")
    @Operation(summary = "Retorna produto ativo por id do produto", description = "Retorna produto ativo por id do produto")
    public ResponseEntity<Produto> consultaProduto(@PathVariable("idProduto") Long id){
        Produto produto = produtoService.buscarProdutoPorId(id);
        return ResponseEntity.ok(produto);
    }

    @PostMapping
    @Operation(summary = "Criar novo produto", description = "Cria um novo registro de produto")
    public ResponseEntity<ProdutoDTO> criarProduto(@Valid @RequestBody ProdutoDTO produtoDTO) {
        ProdutoDTO novoProduto = produtoService.criarProduto(produtoDTO);
        URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
                .buildAndExpand(novoProduto.getId()).toUri();
        return ResponseEntity.created(uri).body(novoProduto);
    }

    @PutMapping("/{idProduto}")
    @Operation(summary = "Atualizar produto", description = "Atualiza um produto existente pelo ID")
    public ResponseEntity<ProdutoDTO> atualizarProduto(
            @PathVariable ("idProduto") Long id,
            @Valid @RequestBody ProdutoDTO produtoDTO) {
        ProdutoDTO produtoAtualizado = produtoService.atualizarProduto(id, produtoDTO);
        return ResponseEntity.ok(produtoAtualizado);
    }

    @DeleteMapping("/{idProduto}")
    @Operation(summary = "Excluir produto", description = "Exclui um produto existente pelo ID")
    public ResponseEntity<Void> excluirProduto(@PathVariable("idProduto") Long id) {
        produtoService.excluirProduto(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/estoque")
    @Operation(summary = "Consulta estoque", description = "Consulta passando os ids desejados pelo JSON")
    public ResponseEntity<List<EstoqueResponseDTO>> consultarEstoque(
            @RequestBody ProdutoEstoqueRequestDTO request) { // Usando o DTO correto
        List<EstoqueResponseDTO> estoque = produtoService.buscarEstoqueDosProdutos(request.getIds());
        return ResponseEntity.ok(estoque);
    }

    @GetMapping("/listar")
    @Operation(summary = "listar todos os produtos", description = "Listar tudo de produto para testes")
    public ResponseEntity<List<Produto>> listarProdutos(){
        return ResponseEntity.status(200).body(produtoService.buscarprodutos());
    }

    @GetMapping("/com-estoque")
    @Operation(summary =  "Produto com Estoque", description = "Consulta de todos os produtos com a quantidade de estoque de cada")
    public ResponseEntity<List<ProdutoComEstoqueDTO>> listarTodosComEstoque() {
        List<ProdutoComEstoqueDTO> produtos = produtoService.buscarTodosProdutosComEstoque();
        return ResponseEntity.ok(produtos);
    }
    // teste
}


