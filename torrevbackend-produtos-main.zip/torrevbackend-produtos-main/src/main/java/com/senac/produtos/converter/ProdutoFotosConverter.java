package com.senac.produtos.converter;

import com.senac.produtos.dto.ProdutoFotosDTO;
import com.senac.produtos.model.ProdutoFotos;
import com.senac.produtos.model.enums.ProdutoFotosStatus;
import com.senac.produtos.repository.ProdutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.function.Function;

@Component
public class ProdutoFotosConverter implements Function<ProdutoFotosDTO, ProdutoFotos> {

    private final ProdutoRepository produtoRepository;

    @Autowired
    public ProdutoFotosConverter(ProdutoRepository produtoRepository) {
        this.produtoRepository = produtoRepository;
    }

    @Override
    public ProdutoFotos apply(ProdutoFotosDTO produtoFotosDTO) {
        Objects.requireNonNull(produtoFotosDTO, "ProdutoFotosDTO não pode ser nulo");

        ProdutoFotos produtoFotos = new ProdutoFotos();
        produtoFotos.setFoto(produtoFotosDTO.getFoto());
        produtoFotos.setInicial(produtoFotosDTO.getInicial());
        produtoFotos.setNomearquivo(produtoFotosDTO.getNomearquivo());
        produtoFotos.setExtensaoarquivo(produtoFotosDTO.getExtensaoarquivo());
        produtoFotos.setStatus(ProdutoFotosStatus.fromCodigo(produtoFotosDTO.getStatus()));

        produtoFotos.setProduto(
                produtoRepository.findById(produtoFotosDTO.getProdutoId())
                        .orElseThrow(() -> new IllegalArgumentException("Produto não encontrado com ID: " + produtoFotosDTO.getProdutoId()))
        );

        return produtoFotos;
    }

}