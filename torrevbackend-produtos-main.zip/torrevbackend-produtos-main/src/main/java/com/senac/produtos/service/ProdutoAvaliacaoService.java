package com.senac.produtos.service;

import com.senac.produtos.converter.ProdutoAvaliacaoConverter;
import com.senac.produtos.converter.ProdutoAvaliacaoDTOConverter;
import com.senac.produtos.dto.ProdutoAvaliacaoDTO;
import com.senac.produtos.model.ProdutoAvaliacao;
import com.senac.produtos.model.enums.ProdutoAvaliacaoStatus;
import com.senac.produtos.repository.ProdutoAvaliacaoRepository;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProdutoAvaliacaoService {

    private final ProdutoAvaliacaoRepository produtoAvaliacaoRepository;
    private final ProdutoAvaliacaoConverter produtoAvaliacaoConverter;
    private final ProdutoAvaliacaoDTOConverter produtoAvaliacaoDTOConverter;

    @Autowired
    public ProdutoAvaliacaoService(ProdutoAvaliacaoRepository produtoAvaliacaoRepository, ProdutoAvaliacaoConverter produtoAvaliacaoConverter, ProdutoAvaliacaoDTOConverter produtoAvaliacaoDTOConverter) {
        this.produtoAvaliacaoRepository = produtoAvaliacaoRepository;
        this.produtoAvaliacaoConverter = produtoAvaliacaoConverter;
        this.produtoAvaliacaoDTOConverter = produtoAvaliacaoDTOConverter;
    }

    @Transactional
    public ProdutoAvaliacaoDTO criarProdutoAvaliacao(ProdutoAvaliacaoDTO produtoAvaliacaoDTO) {
        ProdutoAvaliacao produtoAvaliacao = produtoAvaliacaoConverter.apply(produtoAvaliacaoDTO);
        ProdutoAvaliacao produtoAvaliacaoSalvo = produtoAvaliacaoRepository.save(produtoAvaliacao);
        return produtoAvaliacaoDTOConverter.apply(produtoAvaliacaoSalvo);
    }

    public List<ProdutoAvaliacaoDTO> listarProdutosAvaliacoesAtivos() {
        List<ProdutoAvaliacao> produtoAvaliacoes = produtoAvaliacaoRepository.findByStatus(ProdutoAvaliacaoStatus.ATIVO);
        return produtoAvaliacoes.stream()
                .map(produtoAvaliacaoDTOConverter)
                .toList();
    }

    @Transactional
    public void excluirProdutoAvaliacao(Long id) {
        if (!produtoAvaliacaoRepository.existsById(id)) {
            throw new EntityNotFoundException("Avaliação do produto com id: "+ id +" não encontrado");
        }
        produtoAvaliacaoRepository.deletarProdutoAvaliacaoPorId(id);
    }
}
