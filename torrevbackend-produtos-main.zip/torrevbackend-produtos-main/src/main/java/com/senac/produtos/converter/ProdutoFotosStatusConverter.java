package com.senac.produtos.converter;

import com.senac.produtos.model.enums.ProdutoFotosStatus;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

@Converter(autoApply = true)
public class ProdutoFotosStatusConverter implements AttributeConverter<ProdutoFotosStatus, Integer> {

    @Override
    public Integer convertToDatabaseColumn(ProdutoFotosStatus status) {
        return status == null ? null : status.getCodigo();
    }

    @Override
    public ProdutoFotosStatus convertToEntityAttribute(Integer status) {
        if (status == null) {
            return null;
        }
        return ProdutoFotosStatus.fromCodigo(status);
    }
}
