package com.senac.produtos.converter;

import com.senac.produtos.dto.FabricanteDTO;
import com.senac.produtos.model.Fabricante;
import com.senac.produtos.model.enums.FabricanteStatus;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.function.Function;

@Component
public class FabricanteConverter implements Function<FabricanteDTO, Fabricante> {

    @Override
    public Fabricante apply(FabricanteDTO fornecedorDTO) {
        Objects.requireNonNull(fornecedorDTO, "FornecedorDTO não pode ser nulo");

        Fabricante fabricante = new Fabricante();
        fabricante.setNome(fornecedorDTO.getNome());
        fabricante.setIdentificacao(fornecedorDTO.getIdentificacao());
        fabricante.setTipo(fornecedorDTO.getTipo());
        fabricante.setEmail(fornecedorDTO.getEmail());
        fabricante.setTelefone(fornecedorDTO.getTelefone());
        fabricante.setStatus(FabricanteStatus.fromCodigo(fornecedorDTO.getStatus()));

        return fabricante;
    }
}