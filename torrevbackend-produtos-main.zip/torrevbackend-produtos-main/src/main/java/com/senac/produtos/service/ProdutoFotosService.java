package com.senac.produtos.service;

import com.senac.produtos.converter.ProdutoFotosConverter;
import com.senac.produtos.converter.ProdutoFotosDTOConverter;
import com.senac.produtos.dto.ProdutoFotosDTO;
import com.senac.produtos.model.ProdutoFotos;
import com.senac.produtos.model.enums.ProdutoFotosStatus;
import com.senac.produtos.repository.ProdutoFotosRepository;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProdutoFotosService {
    private final ProdutoFotosRepository produtoFotosRepository;
    private final ProdutoFotosConverter produtoFotosConverter;
    private final ProdutoFotosDTOConverter produtoFotosDTOConverter;

    @Autowired
    public ProdutoFotosService(ProdutoFotosRepository produtoFotosRepository, ProdutoFotosConverter produtoFotosConverter, ProdutoFotosDTOConverter produtoFotosDTOConverter) {
        this.produtoFotosRepository = produtoFotosRepository;
        this.produtoFotosConverter = produtoFotosConverter;
        this.produtoFotosDTOConverter = produtoFotosDTOConverter;
    }

    @Transactional
    public ProdutoFotosDTO criarProdutoFoto(ProdutoFotosDTO produtoFotosDTO) {
        ProdutoFotos produtoFotos = produtoFotosConverter.apply(produtoFotosDTO);
        ProdutoFotos produtoFotosSalvo = produtoFotosRepository.save(produtoFotos);
        return produtoFotosDTOConverter.apply(produtoFotosSalvo);
    }

    public List<ProdutoFotosDTO> listarProdutoFotosAtivos() {
        List<ProdutoFotos> produtosFotos = produtoFotosRepository.findByStatus(ProdutoFotosStatus.ATIVO);
        return produtosFotos.stream()
                .map(produtoFotosDTOConverter)
                .toList();
    }

    @Transactional
    public void excluirProdutoFotos(Long id) {
        if (!produtoFotosRepository.existsById(id)) {
            throw new EntityNotFoundException("Foto do produto com id: "+ id +" não encontrado");
        }
        produtoFotosRepository.deletarProdutoFotosPorId(id);
    }

}
