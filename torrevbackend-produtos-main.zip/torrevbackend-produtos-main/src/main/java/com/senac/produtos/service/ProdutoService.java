package com.senac.produtos.service;

import com.senac.produtos.client.EstoqueClient;
import com.senac.produtos.converter.ProdutoConverter;
import com.senac.produtos.converter.ProdutoDTOConverter;
import com.senac.produtos.dto.ProdutoComEstoqueDTO;
import com.senac.produtos.dto.ProdutoDTO;
import com.senac.produtos.dto.response.EstoqueResponseDTO;
import com.senac.produtos.model.Categoria;
import com.senac.produtos.model.Fabricante;
import com.senac.produtos.model.Produto;
import com.senac.produtos.model.enums.ProdutoStatus;
import com.senac.produtos.model.enums.ProdutoTipo;
import com.senac.produtos.repository.CategoriaRepository;
import com.senac.produtos.repository.FabricanteRepository;
import com.senac.produtos.repository.ProdutoRepository;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProdutoService {

    private final ProdutoRepository produtoRepository;
    private final ProdutoConverter produtoConverter;
    private final ProdutoDTOConverter produtoDTOConverter;
    private final FabricanteRepository fabricanteRepository;
    private final CategoriaRepository categoriaRepository;

    @Autowired
    private EstoqueClient estoqueClient;

    @Autowired
    public ProdutoService(ProdutoRepository produtoRepository,
                          ProdutoConverter produtoConverter,
                          ProdutoDTOConverter produtoDTOConverter,
                          FabricanteRepository fabricanteRepository,
                          CategoriaRepository categoriaRepository) {
        this.produtoRepository = produtoRepository;
        this.produtoConverter = produtoConverter;
        this.produtoDTOConverter = produtoDTOConverter;
        this.fabricanteRepository = fabricanteRepository;
        this.categoriaRepository = categoriaRepository;

    }

    @Transactional
    public ProdutoDTO criarProduto(ProdutoDTO produtoDTO) {
        Produto produto = produtoConverter.apply(produtoDTO);
        Produto produtoSalvo = produtoRepository.save(produto);
        return produtoDTOConverter.apply(produtoSalvo);
    }

    public List<ProdutoDTO> listarProdutosAtivos() {
        List<Produto> produtos = produtoRepository.findByStatus(ProdutoStatus.ATIVO);
        return produtos.stream()
                .map(produtoDTOConverter)
                .toList();
    }

    @Transactional
    public ProdutoDTO atualizarProduto(Long id, ProdutoDTO produtoDTO) {
        Produto produtoExistente = produtoRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Produto não encontrado"));

        produtoExistente.setNome(produtoDTO.getNome());
        produtoExistente.setDescricao(produtoDTO.getDescricao());

        if (produtoDTO.getStatus() != null) {
            produtoExistente.setStatus(ProdutoStatus.fromCodigo(produtoDTO.getStatus()));
        }

        if (produtoDTO.getTipo() != null) {
            produtoExistente.setTipo(ProdutoTipo.fromCodigo(produtoDTO.getTipo()));
        }

        if (produtoDTO.getFabricanteId() != null) {
            Fabricante fabricante = fabricanteRepository.findById(produtoDTO.getFabricanteId())
                    .orElseThrow(() -> new EntityNotFoundException("Fabricante não encontrado"));
            produtoExistente.setFabricante(fabricante);
        }

        if (produtoDTO.getCategoriaId() != null) {
            Categoria categoria = categoriaRepository.findById(produtoDTO.getCategoriaId())
                    .orElseThrow(() -> new EntityNotFoundException("Categoria não encontrada"));
            produtoExistente.setCategoria(categoria);
        }

        Produto produtoAtualizado = produtoRepository.save(produtoExistente);
        return produtoDTOConverter.apply(produtoAtualizado);
    }

    @Transactional
    public void excluirProduto(Long id) {
        if (!produtoRepository.existsById(id)) {
            throw new EntityNotFoundException("Produto não encontrado");
        }
        produtoRepository.deletarProdutoPorId(id);
    }

    public List<EstoqueResponseDTO> buscarEstoqueDosProdutos(List<Long> idsProdutos) {
        if (idsProdutos == null || idsProdutos.isEmpty()) {
            throw new IllegalArgumentException("Lista de IDs não pode ser vazia");
        }
        return estoqueClient.obterQuantidadeDeProduto(idsProdutos);
    }


    public List<Produto>buscarprodutos(){
        return produtoRepository.findAll();
    }

    public Produto buscarProdutoPorId(Long id){
        return produtoRepository.findById(id).orElse(null);
    }

    public List<ProdutoComEstoqueDTO> buscarTodosProdutosComEstoque() {
        // 1. Busca todos os IDs de produtos no banco local
        List<Long> idsProdutos = produtoRepository.findAllProdutosIdsAtivos();

        // 2. Consulta a API de Estoque com os IDs
        List<EstoqueResponseDTO> estoques = estoqueClient.obterQuantidadeDeProduto(idsProdutos);

        // 3. Combina os dados
        return produtoRepository.findAll().stream()
                .map(produto -> {
                    Integer quantidade = estoques.stream()
                            .filter(e -> e.getProdutoId().equals(produto.getId()))
                            .findFirst()
                            .map(EstoqueResponseDTO::getQuantidade)
                            .orElse(0); // Se não houver estoque, retorna 0

                    return new ProdutoComEstoqueDTO(produto, quantidade);
                })
                .collect(Collectors.toList());
    }

}
