package com.senac.produtos.model.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum ProdutoTipo {
    PRODUTO(0),
    EVENTO(1),
    VISITACAO(2),
    DOACAO(3);

    private final int codigo;

    ProdutoTipo(int codigo) {
        this.codigo = codigo;
    }

    @JsonValue
    public int getCodigo() {
        return codigo;
    }

    @JsonCreator
    public static ProdutoTipo fromCodigo(int codigo) {
        for (ProdutoTipo status : ProdutoTipo.values()) {
            if (status.codigo == codigo) {
                return status;
            }
        }
        throw new IllegalArgumentException("Código inválido: " + codigo);
    }
}