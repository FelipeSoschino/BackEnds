package com.senac.produtos.repository;

import com.senac.produtos.model.Categoria;
import com.senac.produtos.model.enums.CategoriaStatus;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CategoriaRepository extends JpaRepository<Categoria, Long> {
    List<Categoria> findByStatus (CategoriaStatus categoriaStatus);

    //Query para deletar categorias
    @Modifying
    @Transactional
    @Query(value = "UPDATE Categoria SET categoria_status = -1 WHERE categoria_id = :id", nativeQuery = true)
    void deletarCategoriaPorId(@Param("id") Long id);
}
