package com.senac.produtos.model.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum ProdutoAvaliacaoStatus {
    INATIVO(0),
    ATIVO(1);


    private final int codigo;

    ProdutoAvaliacaoStatus(int codigo) {
        this.codigo = codigo;
    }

    @JsonValue
    public int getCodigo() {
        return codigo;
    }

    @JsonCreator
    public static ProdutoAvaliacaoStatus fromCodigo(int codigo) {
        for (ProdutoAvaliacaoStatus status : ProdutoAvaliacaoStatus.values()) {
            if (status.codigo == codigo) {
                return status;
            }
        }
        throw new IllegalArgumentException("Código inválido: " + codigo);
    }
}
