package com.senac.produtos.repository;

import com.senac.produtos.model.ProdutoAvaliacao;
import com.senac.produtos.model.enums.ProdutoAvaliacaoStatus;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProdutoAvaliacaoRepository extends JpaRepository<ProdutoAvaliacao, Long> {
    List<ProdutoAvaliacao> findByStatus (ProdutoAvaliacaoStatus produtoAvaliacaoStatus);

    //Query para deletar Avaliacoes do produto
    @Modifying
    @Transactional
    @Query(value = "UPDATE Produto_avaliacao SET produto_avaliacao_status = -1 WHERE produto_avaliacao_id = :id", nativeQuery = true)
    void deletarProdutoAvaliacaoPorId(@Param("id") Long id);
}
