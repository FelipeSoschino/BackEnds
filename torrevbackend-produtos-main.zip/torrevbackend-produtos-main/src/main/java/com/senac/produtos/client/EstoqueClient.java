package com.senac.produtos.client;

import com.senac.produtos.dto.response.EstoqueResponseDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

@FeignClient(name = "estoque-service", url= "http://localhost:8081/api/v1/estoque")
public interface EstoqueClient {

    @PostMapping("/quantidade")
    List<EstoqueResponseDTO> obterQuantidadeDeProduto(@RequestBody List<Long> idsProtudos);

}
