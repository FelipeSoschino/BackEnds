package com.senac.produtos.service;

import com.senac.produtos.converter.CategoriaConverter;
import com.senac.produtos.converter.CategoriaDTOConverter;
import com.senac.produtos.dto.CategoriaDTO;
import com.senac.produtos.model.Categoria;
import com.senac.produtos.model.enums.CategoriaStatus;
import com.senac.produtos.repository.CategoriaRepository;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoriaService {
    private final CategoriaRepository categoriaRepository;
    private final CategoriaConverter categoriaConverter;
    private final CategoriaDTOConverter categoriaDTOConverter;

    public CategoriaService(CategoriaRepository categoriaRepository, CategoriaConverter categoriaConverter, CategoriaDTOConverter categoriaDTOConverter) {
        this.categoriaRepository = categoriaRepository;
        this.categoriaConverter = categoriaConverter;
        this.categoriaDTOConverter = categoriaDTOConverter;
    }

    @Transactional
    public CategoriaDTO criarCategoria(CategoriaDTO categoriaDTO) {
        Categoria categoria = categoriaConverter.apply(categoriaDTO);
        Categoria categoriaSalvo = categoriaRepository.save(categoria);
        return categoriaDTOConverter.apply(categoriaSalvo);
    }

    public List<CategoriaDTO> listarCategoriasAtivas() {
        List<Categoria> categorias = categoriaRepository.findByStatus(CategoriaStatus.ATIVO);
        return categorias.stream()
                .map(categoriaDTOConverter)
                .toList();
    }

    @Transactional
    public void excluirCategoria(Long id) {
        if (!categoriaRepository.existsById(id)) {
            throw new EntityNotFoundException("Categoria com id: "+ id +" não encontrado");
        }
        categoriaRepository.deletarCategoriaPorId(id);
    }
}
