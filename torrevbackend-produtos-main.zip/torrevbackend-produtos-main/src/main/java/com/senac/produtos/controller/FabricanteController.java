package com.senac.produtos.controller;

import com.senac.produtos.dto.FabricanteDTO;
import com.senac.produtos.service.FabricanteService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("api/v1/fabricante")
@Tag(name = "Fornecedor", description = "API para gerenciamento do fabricante do produto")
public class FabricanteController {

    private final FabricanteService fabricanteService;

    @Autowired
    public FabricanteController(FabricanteService fornecedorService) {
        this.fabricanteService = fornecedorService;
    }


    @GetMapping("/ativos")
    @Operation(summary = "Listar fabricantes com status ativo", description = "Lista todos os fabricantes com status ativo")
    public ResponseEntity<List<FabricanteDTO>> listarFabricantesAtivos() {
        return ResponseEntity.ok(fabricanteService.listarFabricantesAtivos());
    }

    @PostMapping
    @Operation(summary = "Criar novo fabricante", description = "Cria um novo registro de fabricante")
    public ResponseEntity<FabricanteDTO> criarFabricante(@Valid @RequestBody FabricanteDTO fabricanteDTO) {
        FabricanteDTO novoFabricante = fabricanteService.criarFabricante(fabricanteDTO);
        URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
                .buildAndExpand(novoFabricante.getId()).toUri();
        return ResponseEntity.created(uri).body(novoFabricante);
    }
    @DeleteMapping("/{idFabricante}")
    @Operation(summary = "Excluir fabricante", description = "Exclui um fabricante existente pelo ID")
    public ResponseEntity<Void> excluirFabricante(@PathVariable("idFabricante") Long id) {
        fabricanteService.excluirFabricante(id);
        return ResponseEntity.noContent().build();
    }
}
