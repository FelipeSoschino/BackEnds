package com.senac.produtos.converter;

import com.senac.produtos.dto.ProdutoAvaliacaoDTO;
import com.senac.produtos.model.ProdutoAvaliacao;
import org.springframework.stereotype.Component;

import java.util.function.Function;

@Component
public class ProdutoAvaliacaoDTOConverter implements Function<ProdutoAvaliacao, ProdutoAvaliacaoDTO> {
    @Override
    public ProdutoAvaliacaoDTO apply(ProdutoAvaliacao produtoAvaliacao) {

        if (produtoAvaliacao == null) {
            return null;
        }

        ProdutoAvaliacaoDTO dto = new ProdutoAvaliacaoDTO();
        dto.setId(produtoAvaliacao.getId());
        dto.setDescricao(produtoAvaliacao.getDescricao());
        dto.setData(produtoAvaliacao.getData());
        dto.setStatus(produtoAvaliacao.getStatus().getCodigo());
        dto.setNota(produtoAvaliacao.getNota());
        dto.setProdutoId(produtoAvaliacao.getProduto().getId());
        return dto;
    }
}
