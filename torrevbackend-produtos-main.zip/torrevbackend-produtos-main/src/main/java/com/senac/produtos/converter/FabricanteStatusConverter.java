package com.senac.produtos.converter;

import com.senac.produtos.model.enums.FabricanteStatus;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

@Converter(autoApply = true)
public class FabricanteStatusConverter implements AttributeConverter<FabricanteStatus, Integer> {

    @Override
    public Integer convertToDatabaseColumn(FabricanteStatus status) {
        return status == null ? null : status.getCodigo();
    }

    @Override
    public FabricanteStatus convertToEntityAttribute(Integer status) {
        if (status == null) {
            return null;
        }
        return FabricanteStatus.fromCodigo(status);
    }
}
