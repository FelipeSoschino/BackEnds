package com.senac.produtos.converter;

import com.senac.produtos.dto.ProdutoFotosDTO;
import com.senac.produtos.model.ProdutoFotos;
import org.springframework.stereotype.Component;

import java.util.function.Function;

@Component
public class ProdutoFotosDTOConverter implements Function<ProdutoFotos, ProdutoFotosDTO> {
    @Override
    public ProdutoFotosDTO apply(ProdutoFotos produtoFotos) {

        if (produtoFotos == null) {
            return null;
        }

        ProdutoFotosDTO dto = new ProdutoFotosDTO();
        dto.setId(produtoFotos.getId());
        dto.setFoto(produtoFotos.getFoto());
        dto.setInicial(produtoFotos.getInicial());
        dto.setNomearquivo(produtoFotos.getNomearquivo());
        dto.setExtensaoarquivo(produtoFotos.getExtensaoarquivo());
        dto.setStatus(produtoFotos.getStatus().getCodigo());
        dto.setProdutoId(produtoFotos.getProduto().getId());
        return dto;
    }
}
