package com.senac.produtos.converter;

import com.senac.produtos.dto.FabricanteDTO;
import com.senac.produtos.model.Fabricante;
import org.springframework.stereotype.Component;

import java.util.function.Function;

@Component
public class FabricanteDTOConverter implements Function<Fabricante, FabricanteDTO> {

    @Override
    public FabricanteDTO apply(Fabricante fabricante) {

        if (fabricante == null) {
            return null;
        }

        FabricanteDTO dto = new FabricanteDTO();
        dto.setId(fabricante.getId());
        dto.setNome(fabricante.getNome());
        dto.setIdentificacao(fabricante.getIdentificacao());
        dto.setTipo(fabricante.getTipo());
        dto.setEmail(fabricante.getEmail());
        dto.setTelefone(fabricante.getTelefone());
        dto.setStatus(fabricante.getStatus().getCodigo());

        return dto;
    }
}