package com.senac.produtos.model.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum ProdutoFotosStatus {
    INATIVO(0),
    ATIVO(1);


    private final int codigo;

    ProdutoFotosStatus(int codigo) {
        this.codigo = codigo;
    }

    @JsonValue
    public int getCodigo() {
        return codigo;
    }

    @JsonCreator
    public static ProdutoFotosStatus fromCodigo(int codigo) {
        for (ProdutoFotosStatus status : ProdutoFotosStatus.values()) {
            if (status.codigo == codigo) {
                return status;
            }
        }
        throw new IllegalArgumentException("Código inválido: " + codigo);
    }
}
