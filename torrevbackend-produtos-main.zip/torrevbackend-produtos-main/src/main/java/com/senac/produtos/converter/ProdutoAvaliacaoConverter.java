package com.senac.produtos.converter;

import com.senac.produtos.dto.ProdutoAvaliacaoDTO;
import com.senac.produtos.model.ProdutoAvaliacao;
import com.senac.produtos.model.enums.ProdutoAvaliacaoStatus;
import com.senac.produtos.repository.ProdutoRepository;
import com.senac.produtos.repository.CategoriaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.function.Function;

@Component
public class ProdutoAvaliacaoConverter implements Function<ProdutoAvaliacaoDTO, ProdutoAvaliacao> {

    private final ProdutoRepository produtoRepository;

    @Autowired
    public ProdutoAvaliacaoConverter(CategoriaRepository eventoLocalRepository, ProdutoRepository produtoRepository) {
        this.produtoRepository = produtoRepository;
    }

    @Override
    public ProdutoAvaliacao apply(ProdutoAvaliacaoDTO produtoAvaliacaoDTO) {
        Objects.requireNonNull(produtoAvaliacaoDTO, "ProdutoAvaliacaoDTO não pode ser nulo");

        ProdutoAvaliacao produtoAvaliacao = new ProdutoAvaliacao();
        produtoAvaliacao.setDescricao(produtoAvaliacaoDTO.getDescricao());
        produtoAvaliacao.setData(produtoAvaliacaoDTO.getData());
        produtoAvaliacao.setStatus(ProdutoAvaliacaoStatus.fromCodigo(produtoAvaliacaoDTO.getStatus()));
        produtoAvaliacao.setNota(produtoAvaliacaoDTO.getNota());

        produtoAvaliacao.setProduto(
                produtoRepository.findById(produtoAvaliacaoDTO.getProdutoId())
                        .orElseThrow(() -> new IllegalArgumentException("Produto não encontrado com ID: " + produtoAvaliacaoDTO.getProdutoId()))
        );

        return produtoAvaliacao;
    }

}