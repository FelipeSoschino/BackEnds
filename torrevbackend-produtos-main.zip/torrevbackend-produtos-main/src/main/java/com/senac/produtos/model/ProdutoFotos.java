package com.senac.produtos.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.senac.produtos.converter.ProdutoFotosStatusConverter;
import com.senac.produtos.model.enums.ProdutoFotosStatus;
import jakarta.persistence.*;
import jakarta.validation.constraints.Null;

@Entity
@Table(name = "produto_fotos")
public class ProdutoFotos {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "produto_fotos_id")
    private Long id;
    @Column(name = "produto_fotos_foto")
    private Byte foto;
    @Column(name = "produto_fotos_inicial")
    private Integer inicial;
    @Column(name = "produto_fotos_nomearquivo")
    private String nomearquivo;
    @Column(name = "produto_fotos_extensaoarquivo")
    private String extensaoarquivo;
    @Column(name = "produto_fotos_status")
    @Convert(converter = ProdutoFotosStatusConverter.class)
    private ProdutoFotosStatus status;

    @ManyToOne
    @JoinColumn(name = "produto_id", nullable = true)
    @Null
    @JsonIgnore
    private Produto produto;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Byte getFoto() {
        return foto;
    }

    public void setFoto(Byte foto) {
        this.foto = foto;
    }

    public Integer getInicial() {
        return inicial;
    }

    public void setInicial(Integer inicial) {
        this.inicial = inicial;
    }

    public String getNomearquivo() {
        return nomearquivo;
    }

    public void setNomearquivo(String nomearquivo) {
        this.nomearquivo = nomearquivo;
    }

    public String getExtensaoarquivo() {
        return extensaoarquivo;
    }

    public void setExtensaoarquivo(String extensaoarquivo) {
        this.extensaoarquivo = extensaoarquivo;
    }

    public ProdutoFotosStatus getStatus() {
        return status;
    }

    public void setStatus(ProdutoFotosStatus status) {
        this.status = status;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }
}
