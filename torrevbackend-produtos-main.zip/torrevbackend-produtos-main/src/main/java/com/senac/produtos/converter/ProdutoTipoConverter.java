package com.senac.produtos.converter;

import com.senac.produtos.model.enums.ProdutoTipo;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

@Converter(autoApply = true)
public class ProdutoTipoConverter implements AttributeConverter<ProdutoTipo, Integer> {

    @Override
    public Integer convertToDatabaseColumn(ProdutoTipo tipo) {
        return tipo == null ? null : tipo.getCodigo();
    }

    @Override
    public ProdutoTipo convertToEntityAttribute(Integer tipo) {
        if (tipo == null) {
            return null;
        }
        return ProdutoTipo.fromCodigo(tipo);
    }
}
