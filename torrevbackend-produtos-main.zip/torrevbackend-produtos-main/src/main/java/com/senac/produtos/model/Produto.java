package com.senac.produtos.model;


import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.senac.produtos.converter.ProdutoStatusConverter;
import com.senac.produtos.converter.ProdutoTipoConverter;
import com.senac.produtos.model.enums.ProdutoStatus;
import com.senac.produtos.model.enums.ProdutoTipo;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;

import java.util.List;

@Entity
@Table(name = "produto")
public class Produto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "produto_id")
    private Long id;

    @Column(name = "produto_nome", nullable = false)
    @NotNull
    private String nome;

    @Column(name = "produto_descricao")
    private String descricao;

    @Column(name = "produto_status")
    @Convert(converter = ProdutoStatusConverter.class)
    private ProdutoStatus status;

    @Column(name = "produto_tipo")
    @Convert(converter = ProdutoTipoConverter.class)
    private ProdutoTipo tipo;

    @OneToMany(mappedBy = "produto", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<ProdutoAvaliacao> produtoAvaliacoes;

    @OneToMany(mappedBy = "produto", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<ProdutoFotos> produtosFotos;

    @ManyToOne
    @JoinColumn(name = "fabricante_id", nullable = false)
    @NotNull
    private Fabricante fabricante;

    @ManyToOne
    @JoinColumn(name = "categoria_id", nullable = false)
    @NotNull
    private Categoria categoria;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public ProdutoStatus getStatus() {
        return status;
    }

    public void setStatus(ProdutoStatus status) {
        this.status = status;
    }

    public ProdutoTipo getTipo() {
        return tipo;
    }

    public void setTipo(ProdutoTipo tipo) {
        this.tipo = tipo;
    }

    public List<ProdutoAvaliacao> getProdutoAvaliacoes() {
        return produtoAvaliacoes;
    }

    public void setProdutoAvaliacoes(List<ProdutoAvaliacao> produtoAvaliacoes) {
        this.produtoAvaliacoes = produtoAvaliacoes;
    }

    public List<ProdutoFotos> getProdutosFotos() {
        return produtosFotos;
    }

    public void setProdutosFotos(List<ProdutoFotos> produtosFotos) {
        this.produtosFotos = produtosFotos;
    }

    public Fabricante getFabricante() {
        return fabricante;
    }

    public void setFabricante(Fabricante fabricante) {
        this.fabricante = fabricante;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }
}