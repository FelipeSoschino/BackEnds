package com.senac.produtos.repository;

import com.senac.produtos.model.ProdutoFotos;
import com.senac.produtos.model.enums.ProdutoFotosStatus;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProdutoFotosRepository extends JpaRepository<ProdutoFotos, Long> {
    List<ProdutoFotos> findByStatus (ProdutoFotosStatus produtoFotosStatus);

    //Query para deletar fotos dos produtos
    @Modifying
    @Transactional
    @Query(value = "UPDATE Produto_fotos SET produto_fotos_status = -1 WHERE produto_fotos_id = :id", nativeQuery = true)
    void deletarProdutoFotosPorId(@Param("id") Long id);
}
