package com.senac.produtos.repository;

import com.senac.produtos.model.Produto;
import com.senac.produtos.model.enums.ProdutoStatus;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProdutoRepository extends JpaRepository<Produto, Long> {
    List<Produto> findByStatus (ProdutoStatus produtoStatus);


    @Query("SELECT p.id FROM Produto p WHERE p.status > 1")
    List<Long> findAllProdutosIdsAtivos();

    //Query para deletar produtos
    @Modifying
    @Transactional
    @Query(value = "UPDATE Produto SET produto_status = -1 WHERE produto_id = :id", nativeQuery = true)
    void deletarProdutoPorId(@Param("id") Long id);
}
