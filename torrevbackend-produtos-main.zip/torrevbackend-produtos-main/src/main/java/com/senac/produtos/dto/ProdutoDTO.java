package com.senac.produtos.dto;

import jakarta.validation.constraints.*;

public class ProdutoDTO {
    private Long id;

    @NotNull(message = "Nome do produto é obrigatório.")
    private String nome;

    private String descricao;

    private Integer status;

    private Integer tipo;

    @NotNull(message = "ID do fabricante é obrigatório.")
    private Long fabricanteId;

    @NotNull(message = "ID da categoria é obrigatório.")
    private Long categoriaId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getTipo() {
        return tipo;
    }

    public void setTipo(Integer tipo) {
        this.tipo = tipo;
    }

    public Long getFabricanteId() {
        return fabricanteId;
    }

    public void setFabricanteId(Long fabricanteId) {
        this.fabricanteId = fabricanteId;
    }

    public Long getCategoriaId() {
        return categoriaId;
    }

    public void setCategoriaId(Long categoriaId) {
        this.categoriaId = categoriaId;
    }
}