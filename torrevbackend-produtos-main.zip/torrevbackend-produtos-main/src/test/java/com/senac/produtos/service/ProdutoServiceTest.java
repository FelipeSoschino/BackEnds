package com.senac.produtos.service;

import com.senac.produtos.converter.ProdutoConverter;
import com.senac.produtos.converter.ProdutoDTOConverter;
import com.senac.produtos.dto.ProdutoDTO;
import com.senac.produtos.exception.ObjectNotFoundException;
import com.senac.produtos.model.Produto;
import com.senac.produtos.model.enums.ProdutoStatus;
import com.senac.produtos.repository.ProdutoRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProdutoServiceTest {

    @Mock
    private ProdutoRepository produtoRepository;

    @Mock
    private ProdutoConverter produtoConverter;

    @Mock
    private ProdutoDTOConverter produtoDTOConverter;

    @InjectMocks
    private ProdutoService produtoService;

    @Test
    @DisplayName("Deve criar um produto com sucesso e retornar o DTO correspondente")
    void deveCriarProdutoComSucesso() {
        ProdutoDTO dtoEntrada = new ProdutoDTO();
        Produto entidade = new Produto();
        Produto entidadeSalva = new Produto();
        ProdutoDTO dtoEsperado = new ProdutoDTO();

        when(produtoConverter.apply(dtoEntrada)).thenReturn(entidade);
        when(produtoRepository.save(entidade)).thenReturn(entidadeSalva);
        when(produtoDTOConverter.apply(entidadeSalva)).thenReturn(dtoEsperado);

        ProdutoDTO resultado = produtoService.criarProduto(dtoEntrada);

        assertEquals(dtoEsperado, resultado);
        verify(produtoConverter).apply(dtoEntrada);
        verify(produtoRepository).save(entidade);
        verify(produtoDTOConverter).apply(entidadeSalva);
    }

    @Test
    @DisplayName("Deve listar produtos ativos e convertê-los para DTOs")
    void deveListarProdutosAtivos() {
        Produto produto1 = new Produto();
        Produto produto2 = new Produto();
        ProdutoDTO dto1 = new ProdutoDTO();
        ProdutoDTO dto2 = new ProdutoDTO();

        when(produtoRepository.findByStatus(ProdutoStatus.ATIVO)).thenReturn(List.of(produto1, produto2));
        when(produtoDTOConverter.apply(produto1)).thenReturn(dto1);
        when(produtoDTOConverter.apply(produto2)).thenReturn(dto2);

        List<ProdutoDTO> resultado = produtoService.listarProdutosAtivos();

        assertEquals(2, resultado.size());
        assertTrue(resultado.contains(dto1));
        assertTrue(resultado.contains(dto2));
        verify(produtoRepository).findByStatus(ProdutoStatus.ATIVO);
    }
}
