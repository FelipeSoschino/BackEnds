# 📦 Microsserviço de Produtos - Torre Verde

## 📚 Índice
1. [Sobre o Projeto](#-sobre-o-projeto)
   - [Tecnologias Utilizadas](#-tecnologias-utilizadas)
   - [Pré-requisitos](#pré-requisitos)
   - [Instalação](#instalação)
2. [Uso](#-uso)
3. [Contribuindo](#-contribuindo)
4. [Commits Semânticos](#commits-semânticos-conventional-commits)
5. [Guia de Estilo de Código](#guia-de-estilo-de-código)

---

## 🎯 Sobre o Projeto
Sistema de gestão de produto desenvolvido para a Torre Verde, permitindo o controle eficiente de produtos, fornecedores e movimentações de produto.

### 🚀 Tecnologias Utilizadas
- Java 17
- Spring Boot 3.x
- MySQL
- Maven
- Swagger/OpenAPI

### Pré-requisitos
- Java JDK 17 ou superior
- Maven 3.8.x ou superior
- MySQL 8.0 ou superior

### Instalação
1. Clone o repositório
```bash
git clone https://github.com/adssenacgit/torrevbackend-produtos.git
cd torrevbackend-produtos
./mvnw
```

---

## 💻 Uso
Após iniciar o projeto, acesse:
- Swagger: http://localhost:8080/swagger-ui.html

## 👥 Contribuindo
1. Crie uma branch seguindo o Gitflow
2. Faça suas alterações seguindo o guia de estilo
3. Escreva testes para suas alterações
4. Envie um Pull Request

---

## Commits Semânticos (Conventional Commits)

Para garantir clareza e padronização no histórico de mudanças do projeto, recomendamos o uso de **conventional commits** como convenção para as mensagens de commit.

### Formato:
- **feat**: Uma nova funcionalidade

- **fix**: Correção de um bug

- **docs**: Apenas mudanças na documentação

- **style**: Alterações de formatação que não afetam o comportamento (espaços, ponto e vírgula, etc)

- **refactor**: Alteração de código que não corrige um bug nem adiciona uma feature

- **test**: Adição ou modificação de testes
 
- **chore**: Tarefas de manutenção (ex: build, configurações, dependências)

### Exemplo
- feat(api): *adicionar endpoint de listagem de produtos*
- fix(auth): *corrigir erro de autenticação com token expirado*
- docs: *atualizar instruções de configuração no README*
- chore: *atualizar versão do checkstyle no pom.xml*

---

## Guia de Estilo de Código

Este projeto segue diretrizes específicas de estilo de código para garantir consistência e legibilidade em toda a base de código. 
As regras a seguir são aplicadas conforme definido no arquivo de configuração `checkstyle.xml`.

### Convenções de Nomenclatura

- **Nomes de classes**: Devem seguir o padrão PascalCase.  
    - Exemplo: `MinhaClasse`

- **Nomes de interfaces**: Devem seguir o padrão PascalCase.  
    - Exemplo: `MinhaInterface`

- **Nomes de métodos**: Devem seguir o padrão camelCase.  
    - Exemplo: `meuMetodo`

- **Nomes de variáveis locais**: Devem seguir o padrão camelCase.  
    - Exemplo: `minhaVariavel`

- **Nomes de constantes**: Devem ser escritos em UPPER_CASE com underscores.  
    - Exemplo: `MINHA_CONSTANTE`

- **Nomes de pacotes**: Devem ser escritos em letras minúsculas.  
    - Exemplo: `com.exemplo.meuprojeto`

- **Nomes de parâmetros**: Devem seguir o padrão camelCase.  
    - Exemplo: `meuParametro`

### Convenção para Endpoints REST

Os **endpoints** da API devem seguir o padrão **kebab-case**, que utiliza letras minúsculas e hífens para separar palavras.  
Essa convenção melhora a legibilidade das URLs e segue boas práticas REST.

### Exemplos:

- ✅ `GET /lista-produtos`
- ✅ `POST /criar-usuario`
- ✅ `PUT /atualizar-dados-pessoais`
- ✅ `DELETE /remover-item`

Evite o uso de camelCase ou PascalCase em caminhos de URL:

- ❌ `/listaProdutos`  
- ❌ `/ListaProdutos`  


### Exemplo

Aqui está um exemplo demonstrando as convenções de nomenclatura:

```java
package com.exemplo.meuprojeto;

@RestController
@RequestMapping("api/v1/usuario")
public class UsuarioController {
    private static final String MENSAGEM_PADRAO = "Olá, ";

    /**
     * Retorna uma saudação personalizada.
     * Exemplo de chamada: GET /saudacao?nome=Gabriel
     */
    @GetMapping("/saudacao")
    public String obterSaudacao(@RequestParam String nome) {
        String saudacaoFormatada = formatarSaudacao(nome);
        return saudacaoFormatada;
    }

    private String formatarSaudacao(String nomeUsuario) {
        return MENSAGEM_PADRAO + nomeUsuario + "!";
    }
}
```

---

Seguir estas diretrizes ajudará a manter a organização e a legibilidade do código em todo o projeto.
